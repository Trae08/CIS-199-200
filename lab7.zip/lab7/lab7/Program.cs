﻿// Grading ID: S1345
// CIS 199-02
// Due Date: 4-4-2021
// This program allows the user to input a positive integer representing the numberof stars per side using methods.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace lab7
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfstars; // represents the user input integer.

            bool valid;// boolean value to validate positive integer input.
            do
            {
                Console.Write(" Enter positive integer representing the number of stars per side: ");
                String positiveInteger = Console.ReadLine();

                valid = int.TryParse(positiveInteger, out numberOfstars) && numberOfstars > 0;
            }

            while (!valid);
            {
                ShowSquareOfStars(numberOfstars);//Method call
            }
                    

                      
                        

        }
        public static void ShowSquareOfStars(int numberOfstars)
        {
            for (int X = 0; X < numberOfstars; X++) // represents number of star rows.

            {
                for (int y = 0; y < numberOfstars; y++)// equals the amount of columns with rows.
                {
                    Console.Write("*");// outputs a stars based on the user input.
                }
                Console.WriteLine(" ");//spaces for the amount of stars in each row and column.
            }
                    
        }










    }
}   

