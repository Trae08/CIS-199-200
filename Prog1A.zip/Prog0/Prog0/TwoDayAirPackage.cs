﻿//ID: 5126336 Program 1A, CIS 200-50, this class sets up NextDay Air package delivery inheriting from airpackage.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    class TwoDayAirPackage: AirPackage// class that inherits from airpackage.
    {
        public enum Delivery { Early, Saver }// enum variable that describes whether its early or saver.

        private Delivery _deliveryType;

        public TwoDayAirPackage(Address originAddress, Address destAddress, double length, double width, double height,double weight, Delivery deliveryType )// constructor that includes delivery type.
            : base(originAddress, destAddress, length,width, height, weight)
        {
            DeliveryType = _deliveryType;

        }

        public Delivery DeliveryType//properity that defines the enum as early or saver and throws exception otherwise.
        {
            get
            {
                return _deliveryType;

            }
            set
            {
                if (Enum.IsDefined(typeof(Delivery), value))
                    _deliveryType = value;
                else
                    throw new ArgumentOutOfRangeException(nameof(value), value, $" {nameof(value)} must be early or saver");

                
            }
        }

        public override decimal CalcCost()// overidden calccost method that adds new base cost formula.
        {
            double disc = .85;
            decimal BaseCost = (decimal)(.18 * (Length + Width + Height) + .20 * (Weight));

            if (DeliveryType == Delivery.Saver)
                BaseCost *= (decimal)disc;
            return BaseCost;
        }

        public override string ToString()// adds new object items from the class to the ToString method.
        {
            string NL = Environment.NewLine;

            return $"TwoDayAirPackage:{NL} {base.ToString()} Delivery Type: {DeliveryType}";
        }
    }

}
