﻿////ID: 5126336 Program 1A, CIS 200-50, this class sets up AirPackage that ingherits from Package.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public abstract class AirPackage: Package// class that inherits from Package.
    {
        //variables that categorize the package.
        public const int HEAVY = 75;
        
        public const int LARGE = 100;
        public AirPackage(Address orginAddress,Address destAddress, double length,double width, double height, double weight ): base(orginAddress, destAddress, length, width, height, weight)//constructor that specifies whats included in an Air Package.
        {

        }
        //Properties that figure out weight classifications.
        public bool IsHeavy()
        {
            return (Weight >= HEAVY);
            
            
                        
        }
        public bool IsLarge()
        {
            double TotalDimension = (Length + Width + Height);
            return (TotalDimension >= LARGE);
        }

        public override string ToString()//returns all new values back to the ToString method.
        {
            string NL = Environment.NewLine;

            return $"{nameof(AirPackage)}{NL}{base.ToString()}{NL} Heavy:{IsHeavy()} Large: {IsLarge()}";
        }
    }
}
