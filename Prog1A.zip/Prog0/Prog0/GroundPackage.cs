﻿//ID: 5126336 Program 1A, CIS 200-50, this class sets up Ground Package that inherits from Package class.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class GroundPackage : Package// class that inherits from package class.
    {
        
        public GroundPackage(Address orginAddress, Address destAddress, double length, double width, double height, double weight) : base(orginAddress, destAddress, length, width, height, weight)// constructor that specifies whats included in a ground package.
        {

        }


        public int ZoneDistance// read-only property defining zone distance
        {
            get
            {
                const int FIRST_DIGIT_FACTOR = 10000;
                int dist = Math.Abs((OriginAddress.Zip / FIRST_DIGIT_FACTOR) - (DestinationAddress.Zip / FIRST_DIGIT_FACTOR));

                return ZoneDistance;
            }

        }
                

        


         public override decimal CalcCost()// gives calccost new values.
        {


            return (decimal)(.15 * (Length + Width + Height) + .07 * (ZoneDistance + 1) * (Weight));
            
        }

        public override string ToString()// returns all new values to the tostring.
        {
            string NL = Environment.NewLine;

            return $"Ground Delivery {NL} {base.ToString()}  Zone Distance: {ZoneDistance}";
        }






    }

}
