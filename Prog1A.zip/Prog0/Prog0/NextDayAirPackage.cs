﻿//ID: 5126336 Program 1A, CIS 200-50, this class sets up Next Day Air Package that inherits from AirPackage class.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    class NextDayAirPackage: AirPackage//class that inherits from Airpackage.
    {
        //Express fee backing field to charge for next day shipping.
        private decimal _expressFee;
        public NextDayAirPackage(Address orginAddress, Address destAddress, double length, double width, double height, double weight, decimal expressfee): base(orginAddress,destAddress,length,width,height, weight)// constructor that defines whats included in NextDay Air delivery.
        {
            ExpressFee = _expressFee;
        }

        public decimal ExpressFee { get;  }// read-only property for the express fee.

        public override decimal CalcCost()// overrides current calccost method and adds charges for weight and size.
        {
              decimal BaseCost = (decimal)(.35 * (Length + Width + Height) + .25 * (Weight)) + ExpressFee;

            double WeightCharge = 20 *(Weight);
            double SizeCharge = .22 * (Length + Width + Height);

            if (IsLarge())
                return BaseCost += (decimal)SizeCharge;
            if (IsHeavy())
                return BaseCost += (decimal)WeightCharge;

            return BaseCost;

        }

        public override string ToString()//returns all new values back to the ToString.
        {
            string NL = Environment.NewLine;
            return $"NextDayAirPackage: {NL} {base.ToString()} ExpressFee: {ExpressFee}";
        }
    }

}
