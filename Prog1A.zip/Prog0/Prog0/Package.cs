﻿//ID: 5126336 Program 1A, CIS 200-50, this class sets up  the package class to inherit from paracel.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public abstract class Package: Parcel//Package class inheriting from parcel.
    {
        //defined values for the package.
        private double _length;
        private double _width;
        private double _height;
        private double _weight;
        public Package(Address orginAddress, Address destAddress, double length, double width, double height, double weight): base(orginAddress,destAddress)// constructor that specifies what the package includes.
        {

            Length = length;
            Width = width;
            Height = height;
            Weight = weight;

        }
        //Get/Set validators for all properties that doesn't allow negative numbers.
        public double Length
        {
            get
            {
                return _length;
            }
            set
            {
                if(value <= 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), $"value cant be zero or negative");
                }
                
                
                    _length = value;
                
            }
        }
        public double Width
        {
            get
            {
                return _width;
            }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), $"value cant be zero or negative");
                }

                _width = value;
            }       
        }
        public double Height
        {
            get
            {
                return _height;
            }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), $"value cant be zero or negative");
                }

                _height = value;
            }
        }
        public double Weight
        {
            get
            {
                return _weight;
            }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), $"value cant be zero or negative");
                }
                _weight = value;
            }
        }
        public override string ToString()// adds package to the ToString method.
        {
            string NL = Environment.NewLine;

            return $"{nameof(Package)}{NL}{base.ToString()}";
        }


    }
}
