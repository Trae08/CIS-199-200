﻿// Grading ID: S1345
// Program 1
// Due Date: 2/16/2021
// CIS199-02

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Program1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        //This button calculates the estimate of materials and labor costs.
        private void CalcEstimatebtn_Click(object sender, EventArgs e)
        {
            const double Labor_Cost_Per_YD = 3.25;// Price of labor per sq yard.
            const double Fertilizer_Cost_Per_YD = 4.25;//Fertilizer price per sq Yard.
            const double SQ_FT_PER_YARD = 9.0;//conversion of sqaure ft to yards.
            const double WasteRate = .10;//the percentage of extra waste.
            const double FirstGardenFee = 50;//fee amount if first garden job is done.



            double width;//declares all variables utlized.
            double length;
            double Price;
            double sqyards;
            double soilcost;
            double fertilizercost;
            double laborcost;
            double totalcost;
            int fertilizer;
            int firstGarden;




            //gathers all the user input for the variables.
            width = double.Parse(MaxWidthtxt.Text);
            length = double.Parse(MaxLengthtxt.Text);
            Price = double.Parse(SoilPricetxt.Text);
            fertilizer = int.Parse(Fertilizertxt.Text);
            firstGarden = int.Parse(FirstGardentxt.Text);

            // calculations for all the estimates.
            sqyards = width * length / SQ_FT_PER_YARD;
            soilcost = Price * sqyards * (1 + WasteRate);
            fertilizercost = sqyards *  Fertilizer_Cost_Per_YD;
            laborcost =  FirstGardenFee + sqyards * Labor_Cost_Per_YD;
            totalcost = soilcost + fertilizercost + laborcost;





            //outputs and formats for all outputs.
            sqyardOutputlbl.Text = $"{sqyards:F1}";
            SoilCostOutputlbl.Text = $"{soilcost,10:C}";
            FertilizerCostOutputlbl.Text = $"{fertilizercost,10:C}";
            LaborCostOutputlbl.Text = $"{laborcost,10:C}";
            TotalCostOutputlbl.Text = $"{totalcost,10:C}";


        }

        private void TotalCostOutputlbl_Click(object sender, EventArgs e)
        {

        }
    }
}
