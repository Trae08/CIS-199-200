﻿
namespace Program1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MaxWidthlbl = new System.Windows.Forms.Label();
            this.MaxLengthlbl = new System.Windows.Forms.Label();
            this.SoilPricelbl = new System.Windows.Forms.Label();
            this.Fertilizerlbl = new System.Windows.Forms.Label();
            this.FirstGardenlbl = new System.Windows.Forms.Label();
            this.sqYardslbl = new System.Windows.Forms.Label();
            this.SoilCostlbl = new System.Windows.Forms.Label();
            this.FertilizerCostlbl = new System.Windows.Forms.Label();
            this.Laborcostlbl = new System.Windows.Forms.Label();
            this.TotalCostlbl = new System.Windows.Forms.Label();
            this.CalcEstimatebtn = new System.Windows.Forms.Button();
            this.MaxWidthtxt = new System.Windows.Forms.TextBox();
            this.MaxLengthtxt = new System.Windows.Forms.TextBox();
            this.SoilPricetxt = new System.Windows.Forms.TextBox();
            this.Fertilizertxt = new System.Windows.Forms.TextBox();
            this.FirstGardentxt = new System.Windows.Forms.TextBox();
            this.sqyardOutputlbl = new System.Windows.Forms.Label();
            this.SoilCostOutputlbl = new System.Windows.Forms.Label();
            this.FertilizerCostOutputlbl = new System.Windows.Forms.Label();
            this.LaborCostOutputlbl = new System.Windows.Forms.Label();
            this.TotalCostOutputlbl = new System.Windows.Forms.Label();
            this.Title = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // MaxWidthlbl
            // 
            this.MaxWidthlbl.AutoSize = true;
            this.MaxWidthlbl.Location = new System.Drawing.Point(178, 56);
            this.MaxWidthlbl.Name = "MaxWidthlbl";
            this.MaxWidthlbl.Size = new System.Drawing.Size(126, 13);
            this.MaxWidthlbl.TabIndex = 0;
            this.MaxWidthlbl.Text = "Max Width of Garden (ft):";
            // 
            // MaxLengthlbl
            // 
            this.MaxLengthlbl.AutoSize = true;
            this.MaxLengthlbl.Location = new System.Drawing.Point(173, 85);
            this.MaxLengthlbl.Name = "MaxLengthlbl";
            this.MaxLengthlbl.Size = new System.Drawing.Size(131, 13);
            this.MaxLengthlbl.TabIndex = 1;
            this.MaxLengthlbl.Text = "Max Length of Garden (ft):";
            // 
            // SoilPricelbl
            // 
            this.SoilPricelbl.AutoSize = true;
            this.SoilPricelbl.Location = new System.Drawing.Point(213, 116);
            this.SoilPricelbl.Name = "SoilPricelbl";
            this.SoilPricelbl.Size = new System.Drawing.Size(91, 13);
            this.SoilPricelbl.TabIndex = 2;
            this.SoilPricelbl.Text = "Soil Price (sq. yd):";
            // 
            // Fertilizerlbl
            // 
            this.Fertilizerlbl.AutoSize = true;
            this.Fertilizerlbl.Location = new System.Drawing.Point(216, 145);
            this.Fertilizerlbl.Name = "Fertilizerlbl";
            this.Fertilizerlbl.Size = new System.Drawing.Size(92, 39);
            this.Fertilizerlbl.TabIndex = 3;
            this.Fertilizerlbl.Text = "             Fertilizer:\r\n\r\n(1 = YES, 0 = NO)";
            // 
            // FirstGardenlbl
            // 
            this.FirstGardenlbl.AutoSize = true;
            this.FirstGardenlbl.Location = new System.Drawing.Point(212, 193);
            this.FirstGardenlbl.Name = "FirstGardenlbl";
            this.FirstGardenlbl.Size = new System.Drawing.Size(100, 26);
            this.FirstGardenlbl.TabIndex = 4;
            this.FirstGardenlbl.Text = "           First Garden:\r\n(1 = YES, 0 = NO)";
            // 
            // sqYardslbl
            // 
            this.sqYardslbl.AutoSize = true;
            this.sqYardslbl.Location = new System.Drawing.Point(240, 270);
            this.sqYardslbl.Name = "sqYardslbl";
            this.sqYardslbl.Size = new System.Drawing.Size(56, 13);
            this.sqYardslbl.TabIndex = 5;
            this.sqYardslbl.Text = "Sq. Yards:";
            // 
            // SoilCostlbl
            // 
            this.SoilCostlbl.AutoSize = true;
            this.SoilCostlbl.Location = new System.Drawing.Point(245, 311);
            this.SoilCostlbl.Name = "SoilCostlbl";
            this.SoilCostlbl.Size = new System.Drawing.Size(51, 13);
            this.SoilCostlbl.TabIndex = 6;
            this.SoilCostlbl.Text = "Soil Cost:";
            // 
            // FertilizerCostlbl
            // 
            this.FertilizerCostlbl.AutoSize = true;
            this.FertilizerCostlbl.Location = new System.Drawing.Point(224, 367);
            this.FertilizerCostlbl.Name = "FertilizerCostlbl";
            this.FertilizerCostlbl.Size = new System.Drawing.Size(72, 13);
            this.FertilizerCostlbl.TabIndex = 7;
            this.FertilizerCostlbl.Text = "Fertilizer Cost:";
            // 
            // Laborcostlbl
            // 
            this.Laborcostlbl.AutoSize = true;
            this.Laborcostlbl.Location = new System.Drawing.Point(235, 407);
            this.Laborcostlbl.Name = "Laborcostlbl";
            this.Laborcostlbl.Size = new System.Drawing.Size(61, 13);
            this.Laborcostlbl.TabIndex = 8;
            this.Laborcostlbl.Text = "Labor Cost:";
            // 
            // TotalCostlbl
            // 
            this.TotalCostlbl.AutoSize = true;
            this.TotalCostlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalCostlbl.Location = new System.Drawing.Point(235, 446);
            this.TotalCostlbl.Name = "TotalCostlbl";
            this.TotalCostlbl.Size = new System.Drawing.Size(69, 13);
            this.TotalCostlbl.TabIndex = 9;
            this.TotalCostlbl.Text = "Total Cost:";
            // 
            // CalcEstimatebtn
            // 
            this.CalcEstimatebtn.Location = new System.Drawing.Point(241, 490);
            this.CalcEstimatebtn.Name = "CalcEstimatebtn";
            this.CalcEstimatebtn.Size = new System.Drawing.Size(148, 23);
            this.CalcEstimatebtn.TabIndex = 10;
            this.CalcEstimatebtn.Text = "Calculate Estimate";
            this.CalcEstimatebtn.UseVisualStyleBackColor = true;
            this.CalcEstimatebtn.Click += new System.EventHandler(this.CalcEstimatebtn_Click);
            // 
            // MaxWidthtxt
            // 
            this.MaxWidthtxt.Location = new System.Drawing.Point(312, 56);
            this.MaxWidthtxt.Name = "MaxWidthtxt";
            this.MaxWidthtxt.Size = new System.Drawing.Size(100, 20);
            this.MaxWidthtxt.TabIndex = 11;
            // 
            // MaxLengthtxt
            // 
            this.MaxLengthtxt.Location = new System.Drawing.Point(312, 82);
            this.MaxLengthtxt.Name = "MaxLengthtxt";
            this.MaxLengthtxt.Size = new System.Drawing.Size(100, 20);
            this.MaxLengthtxt.TabIndex = 12;
            // 
            // SoilPricetxt
            // 
            this.SoilPricetxt.Location = new System.Drawing.Point(312, 116);
            this.SoilPricetxt.Name = "SoilPricetxt";
            this.SoilPricetxt.Size = new System.Drawing.Size(100, 20);
            this.SoilPricetxt.TabIndex = 13;
            // 
            // Fertilizertxt
            // 
            this.Fertilizertxt.Location = new System.Drawing.Point(312, 145);
            this.Fertilizertxt.Name = "Fertilizertxt";
            this.Fertilizertxt.Size = new System.Drawing.Size(100, 20);
            this.Fertilizertxt.TabIndex = 14;
            // 
            // FirstGardentxt
            // 
            this.FirstGardentxt.Location = new System.Drawing.Point(312, 190);
            this.FirstGardentxt.Name = "FirstGardentxt";
            this.FirstGardentxt.Size = new System.Drawing.Size(100, 20);
            this.FirstGardentxt.TabIndex = 15;
            // 
            // sqyardOutputlbl
            // 
            this.sqyardOutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqyardOutputlbl.Location = new System.Drawing.Point(312, 261);
            this.sqyardOutputlbl.Name = "sqyardOutputlbl";
            this.sqyardOutputlbl.Size = new System.Drawing.Size(100, 22);
            this.sqyardOutputlbl.TabIndex = 16;
            // 
            // SoilCostOutputlbl
            // 
            this.SoilCostOutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SoilCostOutputlbl.Location = new System.Drawing.Point(312, 310);
            this.SoilCostOutputlbl.Name = "SoilCostOutputlbl";
            this.SoilCostOutputlbl.Size = new System.Drawing.Size(100, 23);
            this.SoilCostOutputlbl.TabIndex = 17;
            // 
            // FertilizerCostOutputlbl
            // 
            this.FertilizerCostOutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FertilizerCostOutputlbl.Location = new System.Drawing.Point(312, 357);
            this.FertilizerCostOutputlbl.Name = "FertilizerCostOutputlbl";
            this.FertilizerCostOutputlbl.Size = new System.Drawing.Size(100, 23);
            this.FertilizerCostOutputlbl.TabIndex = 18;
            // 
            // LaborCostOutputlbl
            // 
            this.LaborCostOutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LaborCostOutputlbl.Location = new System.Drawing.Point(312, 397);
            this.LaborCostOutputlbl.Name = "LaborCostOutputlbl";
            this.LaborCostOutputlbl.Size = new System.Drawing.Size(100, 23);
            this.LaborCostOutputlbl.TabIndex = 19;
            // 
            // TotalCostOutputlbl
            // 
            this.TotalCostOutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalCostOutputlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalCostOutputlbl.Location = new System.Drawing.Point(312, 436);
            this.TotalCostOutputlbl.Name = "TotalCostOutputlbl";
            this.TotalCostOutputlbl.Size = new System.Drawing.Size(100, 23);
            this.TotalCostOutputlbl.TabIndex = 20;
            this.TotalCostOutputlbl.Click += new System.EventHandler(this.TotalCostOutputlbl_Click);
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Location = new System.Drawing.Point(270, 19);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(219, 13);
            this.Title.TabIndex = 21;
            this.Title.Text = "EZ-Garden and Landscaping Costs Estimator";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 546);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.TotalCostOutputlbl);
            this.Controls.Add(this.LaborCostOutputlbl);
            this.Controls.Add(this.FertilizerCostOutputlbl);
            this.Controls.Add(this.SoilCostOutputlbl);
            this.Controls.Add(this.sqyardOutputlbl);
            this.Controls.Add(this.FirstGardentxt);
            this.Controls.Add(this.Fertilizertxt);
            this.Controls.Add(this.SoilPricetxt);
            this.Controls.Add(this.MaxLengthtxt);
            this.Controls.Add(this.MaxWidthtxt);
            this.Controls.Add(this.CalcEstimatebtn);
            this.Controls.Add(this.TotalCostlbl);
            this.Controls.Add(this.Laborcostlbl);
            this.Controls.Add(this.FertilizerCostlbl);
            this.Controls.Add(this.SoilCostlbl);
            this.Controls.Add(this.sqYardslbl);
            this.Controls.Add(this.FirstGardenlbl);
            this.Controls.Add(this.Fertilizerlbl);
            this.Controls.Add(this.SoilPricelbl);
            this.Controls.Add(this.MaxLengthlbl);
            this.Controls.Add(this.MaxWidthlbl);
            this.Name = "Form1";
            this.Text = "Program 1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MaxWidthlbl;
        private System.Windows.Forms.Label MaxLengthlbl;
        private System.Windows.Forms.Label SoilPricelbl;
        private System.Windows.Forms.Label Fertilizerlbl;
        private System.Windows.Forms.Label FirstGardenlbl;
        private System.Windows.Forms.Label sqYardslbl;
        private System.Windows.Forms.Label SoilCostlbl;
        private System.Windows.Forms.Label FertilizerCostlbl;
        private System.Windows.Forms.Label Laborcostlbl;
        private System.Windows.Forms.Label TotalCostlbl;
        private System.Windows.Forms.Button CalcEstimatebtn;
        private System.Windows.Forms.TextBox MaxWidthtxt;
        private System.Windows.Forms.TextBox MaxLengthtxt;
        private System.Windows.Forms.TextBox SoilPricetxt;
        private System.Windows.Forms.TextBox Fertilizertxt;
        private System.Windows.Forms.TextBox FirstGardentxt;
        private System.Windows.Forms.Label sqyardOutputlbl;
        private System.Windows.Forms.Label SoilCostOutputlbl;
        private System.Windows.Forms.Label FertilizerCostOutputlbl;
        private System.Windows.Forms.Label LaborCostOutputlbl;
        private System.Windows.Forms.Label TotalCostOutputlbl;
        private System.Windows.Forms.Label Title;
    }
}

