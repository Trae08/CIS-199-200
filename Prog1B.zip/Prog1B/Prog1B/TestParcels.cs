﻿// Program 1B
// CIS 200-50
// Fall 2021
// Due: 10/8/2021
// By: 5126336

// File: TestParcels.cs
// This is a simple, console application designed to exercise the Parcel hierarchy.
// It creates several different Parcels and prints them.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace Prog1
{
    class TestParcels
    {
        
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            bool Verbose = false;
            // Test Data - Magic Numbers OK
            Address a1 = new Address("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
                "  Louisville   ", "  KY   ", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("John Cena", "1010 Strawberry Lane",
                "Tampa Bay", "FL", 28887);
            Address a6 = new Address(" James Bond", "007 GunShotLane", 
                "Louisville", "KY", 40325);
            Address a7 = new Address("Jamie Foxx", " 1112 Fox st.", 
                "Chicago", " IL", 38886);
            Address a8 = new Address("Johnny Cage", "11 Mortal Kombat Way ", 
                "Los Angeles", "CA", 79909);

            Letter letter1 = new Letter(a1, a2, 3.95M);                            // Letter test object
            Letter letter2 = new Letter(a3, a4, 4.25M);
            GroundPackage gp1 = new GroundPackage(a3, a4, 14, 10, 5, 12.5);        // Ground test object
            GroundPackage gp2 = new GroundPackage(a6, a7, 9.2, 6.1, 10.2, 8.4);
            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 25, 15, 15,    // Next Day test object
                85, 7.50M);
            NextDayAirPackage ndap2 = new NextDayAirPackage(a2, a5, 2.5, 3, 5.0,
                35, 5.25M);
            NextDayAirPackage ndap3 = new NextDayAirPackage(a8, a4, 3.5, 5, 6,
                50, 9.99M);
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a4, a1, 46.5, 39.5, 28.0, // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a1, a7, 78.10, 42.0,
                20.5,78, TwoDayAirPackage.Delivery.Early);
            TwoDayAirPackage tdap3 = new TwoDayAirPackage(a5, a2, 12.5, 20.0, 32.2,
                45, TwoDayAirPackage.Delivery.Saver);

            List<Parcel> parcels;      // List of test parcels

            parcels = new List<Parcel>();

            parcels.Add(letter1); // Populate list of test parcels.
            parcels.Add(letter2);
            parcels.Add(gp1);
            parcels.Add(gp2);
            parcels.Add(ndap1);
            parcels.Add(ndap2);
            parcels.Add(ndap3);
            parcels.Add(tdap1);
            parcels.Add(tdap2);
            parcels.Add(tdap3);

            WriteLine("Original List:");
            WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                WriteLine(p);
                WriteLine("====================");
            }
            Pause();

            // Parcels by Destination Zip (descending order)
            var ParcelByZip =
                from p in parcels
                orderby p.DestinationAddress.Zip descending
                select p;

            WriteLine("Parcels  by Destination Zip:");
            WriteLine("====================");

            foreach (Parcel p in ParcelByZip)
            {
                if (Verbose)
                {
                    WriteLine(p);
                    WriteLine("====================");
                }
                else
                {
                    WriteLine($"{p.DestinationAddress.Zip:D5}");
                }
                
            }
            Pause();
               
            
            //Parcels by cost
            var ParcelByCost =
                from p in parcels
                orderby p.CalcCost() 
                select p;


            WriteLine("Parcels by Cost");
            WriteLine("====================");

            foreach(Parcel p in ParcelByCost)
            {
                if (Verbose)
                {
                    WriteLine(p);
                    WriteLine("====================");
                }
                else
                    WriteLine($"{p.CalcCost(),8:C}");
            }
            Pause();

            // Parcels by type and cost
            var parcelsByTypeCost =
                from p in parcels
                orderby p.GetType().ToString(), p.CalcCost() descending
                select p;

            WriteLine("Parcels by Type and Cost");
            WriteLine("====================");

            foreach(Parcel p in parcelsByTypeCost)
            {
                if (Verbose)
                {
                    WriteLine(p);
                    WriteLine("====================");
                }
                else
                    WriteLine($"{p.GetType().ToString(),-17} {p.CalcCost(),8:C}");
            }
            Pause();

            //Heavy AirPackages by weight (descending order)
            var heavyAirPackagesByWeight =
               from p in parcels
               let ap = p as AirPackage
               where (ap != null) && ap.IsHeavy()
               orderby ap.Weight descending
               select ap;

            WriteLine("Heavy Air Packages by Weight:");
            WriteLine("=======================");
            foreach( AirPackage ap in heavyAirPackagesByWeight)
            {
                if (Verbose)
                {
                    WriteLine(ap);
                    WriteLine("====================");
                }
                else
                    WriteLine("{0,-17} {1,4:F1}", ap.GetType().ToString(), ap.Weight);

                
            }
        }

        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            WriteLine("Press Enter to Continue...");
            ReadLine();

            Console.Clear(); // Clear screen
        }


    }
}
