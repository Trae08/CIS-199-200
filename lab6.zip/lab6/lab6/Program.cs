﻿//CIS199-02
//Grading ID:S1345
//Due Date: 03/21/21
//This program uses for loops to create patterns of stars.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace lab6
{
    class Program
    {
        static void Main(string[] args)
        {
            string asterisk = "*";//variable for stars
            const int MAX_ROWS = 10;//represents the total number of asterisk rows
            WriteLine("Pattern A: ");
            for (int row = 1; row <= MAX_ROWS; row++)
            {
                for (int star = 1; star <= row; star++)
                    Write($"{asterisk}");
                WriteLine();
            }
            const int Min_ROWS = 1;
            WriteLine("Pattern B: ");//reverse loop of A
            for (int row = 10; row >= Min_ROWS; row--)
            {
                for (int star = 1; star <= row; star++)
                    Write($"{asterisk}");
                WriteLine();
            }
            WriteLine("Pattern C: ");// pattern C flips pattern B with spaces implented
            for (int row = MAX_ROWS; row >= 1; row--) 
            {
                for (int space = 1; space <= MAX_ROWS - row; space++)
                    Write(" ");
                for (int star = 1; star <= row; star++)
                    Write($"{asterisk}");
                WriteLine();
            }


            WriteLine("Pattern D:");

            for(int row = 1; row <=MAX_ROWS;row++)//Pattern D is a flip of pattern A using spaces to line up the amount of star rows.
            {
                for (int space = 1; space <= MAX_ROWS - row; space++)
                    Write(" ");


                for(int star = 1; star <= row; star++)
                
                    Write($"{ asterisk}");
                
                WriteLine();
            }

            
            

        }
    }
}
