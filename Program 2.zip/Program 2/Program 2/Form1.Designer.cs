﻿
namespace Program_2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Peoplelbl = new System.Windows.Forms.Label();
            this.distancelbl = new System.Windows.Forms.Label();
            this.Deliverydayslbl = new System.Windows.Forms.Label();
            this.Peopletxt = new System.Windows.Forms.TextBox();
            this.Resultslbl = new System.Windows.Forms.Label();
            this.Distancetxt = new System.Windows.Forms.TextBox();
            this.Deilverydaystxt = new System.Windows.Forms.TextBox();
            this.CompanyAlbl = new System.Windows.Forms.Label();
            this.CompanyBlbl = new System.Windows.Forms.Label();
            this.CompanyClbl = new System.Windows.Forms.Label();
            this.CompanyBoutputlbl = new System.Windows.Forms.Label();
            this.CompanyCoutputlbl = new System.Windows.Forms.Label();
            this.Lowestcostoutputlbl = new System.Windows.Forms.Label();
            this.CalcCostbtn = new System.Windows.Forms.Button();
            this.CompanyAoutputlbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Peoplelbl
            // 
            this.Peoplelbl.AutoSize = true;
            this.Peoplelbl.Location = new System.Drawing.Point(110, 99);
            this.Peoplelbl.Name = "Peoplelbl";
            this.Peoplelbl.Size = new System.Drawing.Size(40, 13);
            this.Peoplelbl.TabIndex = 0;
            this.Peoplelbl.Text = "People";
            // 
            // distancelbl
            // 
            this.distancelbl.AutoSize = true;
            this.distancelbl.Location = new System.Drawing.Point(77, 161);
            this.distancelbl.Name = "distancelbl";
            this.distancelbl.Size = new System.Drawing.Size(86, 13);
            this.distancelbl.TabIndex = 1;
            this.distancelbl.Text = "Distance  (MIles)";
            this.distancelbl.Click += new System.EventHandler(this.distancelbl_Click);
            // 
            // Deliverydayslbl
            // 
            this.Deliverydayslbl.AutoSize = true;
            this.Deliverydayslbl.Location = new System.Drawing.Point(78, 227);
            this.Deliverydayslbl.Name = "Deliverydayslbl";
            this.Deliverydayslbl.Size = new System.Drawing.Size(72, 13);
            this.Deliverydayslbl.TabIndex = 2;
            this.Deliverydayslbl.Text = "Delivery Days";
            // 
            // Peopletxt
            // 
            this.Peopletxt.Location = new System.Drawing.Point(172, 92);
            this.Peopletxt.Name = "Peopletxt";
            this.Peopletxt.Size = new System.Drawing.Size(100, 20);
            this.Peopletxt.TabIndex = 3;
            // 
            // Resultslbl
            // 
            this.Resultslbl.AutoSize = true;
            this.Resultslbl.Location = new System.Drawing.Point(383, 48);
            this.Resultslbl.Name = "Resultslbl";
            this.Resultslbl.Size = new System.Drawing.Size(42, 13);
            this.Resultslbl.TabIndex = 4;
            this.Resultslbl.Text = "Results";
            // 
            // Distancetxt
            // 
            this.Distancetxt.Location = new System.Drawing.Point(172, 158);
            this.Distancetxt.Name = "Distancetxt";
            this.Distancetxt.Size = new System.Drawing.Size(100, 20);
            this.Distancetxt.TabIndex = 5;
            // 
            // Deilverydaystxt
            // 
            this.Deilverydaystxt.Location = new System.Drawing.Point(172, 220);
            this.Deilverydaystxt.Name = "Deilverydaystxt";
            this.Deilverydaystxt.Size = new System.Drawing.Size(100, 20);
            this.Deilverydaystxt.TabIndex = 6;
            // 
            // CompanyAlbl
            // 
            this.CompanyAlbl.AutoSize = true;
            this.CompanyAlbl.Location = new System.Drawing.Point(430, 99);
            this.CompanyAlbl.Name = "CompanyAlbl";
            this.CompanyAlbl.Size = new System.Drawing.Size(85, 13);
            this.CompanyAlbl.TabIndex = 7;
            this.CompanyAlbl.Text = "Company A Cost";
            // 
            // CompanyBlbl
            // 
            this.CompanyBlbl.AutoSize = true;
            this.CompanyBlbl.Location = new System.Drawing.Point(430, 161);
            this.CompanyBlbl.Name = "CompanyBlbl";
            this.CompanyBlbl.Size = new System.Drawing.Size(85, 13);
            this.CompanyBlbl.TabIndex = 8;
            this.CompanyBlbl.Text = "Company B Cost";
            // 
            // CompanyClbl
            // 
            this.CompanyClbl.AutoSize = true;
            this.CompanyClbl.Location = new System.Drawing.Point(430, 223);
            this.CompanyClbl.Name = "CompanyClbl";
            this.CompanyClbl.Size = new System.Drawing.Size(85, 13);
            this.CompanyClbl.TabIndex = 9;
            this.CompanyClbl.Text = "Company C Cost";
            // 
            // CompanyBoutputlbl
            // 
            this.CompanyBoutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CompanyBoutputlbl.Location = new System.Drawing.Point(560, 158);
            this.CompanyBoutputlbl.Name = "CompanyBoutputlbl";
            this.CompanyBoutputlbl.Size = new System.Drawing.Size(100, 27);
            this.CompanyBoutputlbl.TabIndex = 11;
            // 
            // CompanyCoutputlbl
            // 
            this.CompanyCoutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CompanyCoutputlbl.Location = new System.Drawing.Point(557, 220);
            this.CompanyCoutputlbl.Name = "CompanyCoutputlbl";
            this.CompanyCoutputlbl.Size = new System.Drawing.Size(100, 27);
            this.CompanyCoutputlbl.TabIndex = 12;
            this.CompanyCoutputlbl.Click += new System.EventHandler(this.CompanyCoutputlbl_Click);
            // 
            // Lowestcostoutputlbl
            // 
            this.Lowestcostoutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lowestcostoutputlbl.Location = new System.Drawing.Point(433, 270);
            this.Lowestcostoutputlbl.Name = "Lowestcostoutputlbl";
            this.Lowestcostoutputlbl.Size = new System.Drawing.Size(227, 23);
            this.Lowestcostoutputlbl.TabIndex = 13;
            // 
            // CalcCostbtn
            // 
            this.CalcCostbtn.Location = new System.Drawing.Point(113, 346);
            this.CalcCostbtn.Name = "CalcCostbtn";
            this.CalcCostbtn.Size = new System.Drawing.Size(97, 26);
            this.CalcCostbtn.TabIndex = 14;
            this.CalcCostbtn.Text = "Calculate Cost";
            this.CalcCostbtn.UseVisualStyleBackColor = true;
            this.CalcCostbtn.Click += new System.EventHandler(this.CalcCostbtn_Click);
            // 
            // CompanyAoutputlbl
            // 
            this.CompanyAoutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CompanyAoutputlbl.Location = new System.Drawing.Point(558, 105);
            this.CompanyAoutputlbl.Name = "CompanyAoutputlbl";
            this.CompanyAoutputlbl.Size = new System.Drawing.Size(100, 23);
            this.CompanyAoutputlbl.TabIndex = 15;
            // 
            // Program2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.CompanyAoutputlbl);
            this.Controls.Add(this.CalcCostbtn);
            this.Controls.Add(this.Lowestcostoutputlbl);
            this.Controls.Add(this.CompanyCoutputlbl);
            this.Controls.Add(this.CompanyBoutputlbl);
            this.Controls.Add(this.CompanyClbl);
            this.Controls.Add(this.CompanyBlbl);
            this.Controls.Add(this.CompanyAlbl);
            this.Controls.Add(this.Deilverydaystxt);
            this.Controls.Add(this.Distancetxt);
            this.Controls.Add(this.Resultslbl);
            this.Controls.Add(this.Peopletxt);
            this.Controls.Add(this.Deliverydayslbl);
            this.Controls.Add(this.distancelbl);
            this.Controls.Add(this.Peoplelbl);
            this.Name = "Program2";
            this.Text = "Food Delivery Cost Calculation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Peoplelbl;
        private System.Windows.Forms.Label distancelbl;
        private System.Windows.Forms.Label Deliverydayslbl;
        private System.Windows.Forms.TextBox Peopletxt;
        private System.Windows.Forms.Label Resultslbl;
        private System.Windows.Forms.TextBox Distancetxt;
        private System.Windows.Forms.TextBox Deilverydaystxt;
        private System.Windows.Forms.Label CompanyAlbl;
        private System.Windows.Forms.Label CompanyBlbl;
        private System.Windows.Forms.Label CompanyClbl;
        private System.Windows.Forms.Label CompanyBoutputlbl;
        private System.Windows.Forms.Label CompanyCoutputlbl;
        private System.Windows.Forms.Label Lowestcostoutputlbl;
        private System.Windows.Forms.Button CalcCostbtn;
        private System.Windows.Forms.Label CompanyAoutputlbl;
    }
}

