﻿//Grading ID: S1345
//CIS199-02
//DueDate: 3/11/2021

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
           

            InitializeComponent();
        }

        private void distancelbl_Click(object sender, EventArgs e)
        {

        }
        
        private void CalcCostbtn_Click(object sender, EventArgs e)
        {
            //All constant variables declared accoridng to the charts provided.
            const int CompanyAPerperson = 1;// company A is $1 per person.
            const double CompanyADistance1 = .02;//A's distance. 
            const int CompanyA1Day = 20, CompanyA2day = 17, CompanyA3day = 15, CompanyA4Day = 10, CompanyA7day = 7;// all of Comapny A delivery day fees.
            const int CompanyBshortdays = 10;//company B 1-4 delivery day fee.
            const int CompanyBLongdays = 7;//company B 4+ day delivery day fee.
            const int CompanyBPeoplelow = 20, CompanyBPeoplemid_low = 10, CompanyBPeopleMid = 5, ComapnyBPeoplemid_high = 3; const double CompanyBPeopleHigh = .15;//Comapny B fee per person.
            const double CompanyBDistance1 = .10;//Distance fee for CompanyB.
            const double CompanyCPeople = .25;//fee per person for CompanyC
            const int ComapnyCDistancelow = 10, CompanyCDistancemid_low = 15, CompanyCDistancemid = 25, CompanyCDistanceMid_high = 35, CompanyCDistancehigh = 40;// distance per mile fee for Company C
            const int CompanyCDays = 20;//Comapny C deliveryday fee
            //All declared variables that will have changing values.
            int days;
            int people;
            double distance;
            //Totals for calculating people cost per company.
            int CompanyAPeopleCost=0;
            double CompanyBPeopleCost=0;
            double CompanyCPeopleCost=0;
            //Totals for calculating distance per mile for every company.
            double CompanyADistanceCost=0;
            double CompanyBDistanceCost=0;
            double CompanyCDistanceCost=0;
            //Totals for calculating the delivery fees per input for every company.
            int CompanyADaysCost=0;
            int CompanyBDaysCost=0;
            int CompanyCDaysCost=0;

            
            
            //declaring the totals per company for calculations.
            double CompanyATotalCost=0;
            double CompanyBTotalCost=0;
            double CompanyCTotalCost=0;

            if (int.TryParse(Peopletxt.Text, out people) && (people >= 0)) 
            {

                CompanyAPeopleCost = people * CompanyAPerperson;// formula for calculates the 

                if (people < 10)
                    CompanyBPeopleCost = people*CompanyBPeoplelow;
                else if (people >=10 && people <50)
                    CompanyBPeopleCost =  people*CompanyBPeoplemid_low;
                else if (people >=50 && people <100)
                    CompanyBPeopleCost =  people*CompanyBPeopleMid;
                else if (people >=100 && people <200)
                    CompanyBPeopleCost =  people* ComapnyBPeoplemid_high;
                else if (people >= 200)
                    CompanyBPeopleCost =  people *CompanyBPeopleHigh;


                CompanyCPeopleCost = people* CompanyCPeople;

            }

            else
            {
                MessageBox.Show("Invalid Number of People");//if invalid number of people is input this message box will display.
            }

            if (double.TryParse(Distancetxt.Text, out distance)&& (distance>=0)) 
            {
                
                
                    CompanyADistanceCost = distance * CompanyADistance1;
                
                    CompanyBDistanceCost = distance * CompanyBDistance1;
                
                    if (distance <= 200)
                        CompanyCDistanceCost =  ComapnyCDistancelow;
                    else if (distance > 200 && distance < 500)
                        CompanyCDistanceCost =  CompanyCDistancemid_low;
                    else if (distance >= 500 && distance <750 )
                        CompanyCDistanceCost =  CompanyCDistancemid;
                    else if (distance >= 750 && distance < 1000 )
                        CompanyCDistanceCost =  CompanyCDistanceMid_high;
                    else if (distance >= 1000)
                        CompanyCDistanceCost =  CompanyCDistancehigh;
                
            }
            else
            {
                MessageBox.Show("Invalid Distance");// if invalid distance has been input this message will show.
            }

            if(int.TryParse(Deilverydaystxt.Text, out days)&& (days>=0))
            {
                
                
                    if (days == 1)
                        CompanyADaysCost =  CompanyA1Day;
                    else if (days == 2)
                        CompanyADaysCost = CompanyA2day;
                    else if (days == 3)
                        CompanyADaysCost = CompanyA3day;
                    else if (days >= 4 && days <= 7)
                        CompanyADaysCost =  CompanyA4Day;
                    else if (days > 7)
                        CompanyADaysCost =  CompanyA7day;
                
                
                
                    if (days >= 1 && days <= 4)
                        CompanyBDaysCost =  CompanyBshortdays;
                    if (days > 4)
                        CompanyBDaysCost =  CompanyBLongdays;
                
               
                
                    CompanyCDaysCost =  CompanyCDays;
                

                
            }
            else
            {
                MessageBox.Show("Invalid Delivery Days");// if invalid days has been input this message will display.
            }



            //summary section/collects the total cost via user inputs.
            CompanyATotalCost = CompanyAPeopleCost + CompanyADistanceCost + CompanyADaysCost;
            CompanyBTotalCost = CompanyBPeopleCost + CompanyBDistanceCost + CompanyBDaysCost;
            CompanyCTotalCost = CompanyCPeopleCost + CompanyCDistanceCost + CompanyCDaysCost;
            // CompanyA,B&C outputlabels formatted in currency.
            CompanyAoutputlbl.Text = $"{CompanyATotalCost:C}";
            CompanyBoutputlbl.Text = $"{CompanyBTotalCost:C}";
            CompanyCoutputlbl.Text = $"{CompanyCTotalCost:C}";

            //Output for lowest cost label/ states which company has the lowest cost.
            if (CompanyATotalCost < CompanyBTotalCost && CompanyATotalCost < CompanyCTotalCost)
                Lowestcostoutputlbl.Text = ($"The lowest cost company is: A ");
            if (CompanyBTotalCost < CompanyATotalCost && CompanyBTotalCost < CompanyCTotalCost)
                Lowestcostoutputlbl.Text = ($"The lowest cost company is: B ");
            if (CompanyCTotalCost < CompanyATotalCost && CompanyCTotalCost < CompanyBTotalCost)
                Lowestcostoutputlbl.Text = ($"The lowest cost company is: C ");









        }

        private void CompanyCoutputlbl_Click(object sender, EventArgs e)
        {

        }
    }
}
