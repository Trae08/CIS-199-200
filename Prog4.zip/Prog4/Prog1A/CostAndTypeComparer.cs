﻿// program 4
//CIS 200-50
//Due: 12/2/2021
//Grading ID: 5126336
// sorts parcels by ascending order by parcel type and then descending order by cost.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class CostAndTypeComparer: Comparer<Parcel>
    {
        //returns 0 if p1 type and p2 type equal each other
        // negative if p1 then cost < p2 type then cost
        // pos if p1 type then cost > p1 tye then cost
        public override int Compare(Parcel p1, Parcel p2)
        {
            string type1;
            string type2;

            if (this == null && p2 == null)// Handles null values in the correct format.
                return 0;

            if (this == null)
                return -1;

            if (p2 == null)
                return 1;

            type1 = p1.GetType().ToString();
            type2 = p2.GetType().ToString();

            if (type1 != type2)
                return type1.CompareTo(type2);

            return (-1) * p1.CompareTo(p2);// Cost in Descending format
        }
    }
}
