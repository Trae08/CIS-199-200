﻿// Program 4
//CIS 200-50
//Due: 12/2/2021
//Grading ID: 5126336
//Creates comparer for parcels that displays zip in  descending zip.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    // Returns 0 of p1.DestinationAddress zip = p2 destination address zip
    // neg if p1 address zip < p2 destination adress zip
    // pos if p1 Destination Address zip > p2 Destination Address Zip
    class DestZipDescendingComparer: Comparer<Parcel>
    {
        public override int Compare(Parcel p1, Parcel p2)
        {
            int zip1;
            int zip2;

            if (p1 == null && p2 == null)// handles null vales correctly.
                return 0;

            if (p1 == null)
                return -1;

            if (p2 == null)
                return 1;

            zip1 = p1.DestinationAddress.Zip;
            zip2 = p2.DestinationAddress.Zip;

            return (-1) * zip1.CompareTo(zip2);// reverses the order/ creates descending order
        }
    }
}
