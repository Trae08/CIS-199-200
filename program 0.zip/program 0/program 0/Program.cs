﻿//student ID: 5126336
//program 0
//Due Date: 9/9/2021
//CIS-200-50
using System;
using System.Collections.Generic;

namespace program_0
{
    class Program
    {
         public static void Main()// displays data from the classes.
        {
            Address a1 = new Address("James Bond", "8079 Riverview Drive", "Apt.25 ", "Decatur", "GA", 30030);
            Address  a2 = new Address("Lebron James", "60 Parker St.",  "Redford", "MI", 48239);
            Address a3 = new Address("Lamontra Peters", "4 St Margarets St.","N/A", "Harleysville PA", 19438);
            Address a4 = new Address("Troy Baker", "8104 Ryan Street", "Gansville", "VA", 20155);

            Letter l1 = new Letter(a1, a3, 1.50M);
            Letter l2 = new Letter(a2, a4, 2.25M);
            Letter l3 = new Letter(a4, a1, .55M);
            List<Parcel> parcels = new List<Parcel>();//adds letters to the list of parcels.

            parcels.Add(l1);
            parcels.Add(l2);
            parcels.Add(l3);
            

                foreach(Parcel parcel in parcels)
            {
                System.Console.WriteLine(parcel);
            }
        }
             
    }

    public abstract class Parcel//abstract class that specifies parcel information.
    {
        private Address orginAddress;
        private Address destinationAddress;

        public Parcel(Address orginAddress, Address destinationAddress)
        {
            
            OrginAddress = orginAddress;
            DestinationAddress = destinationAddress;
        }

        public Address OrginAddress//specifies Address and what it uses.
        {
            get
            {
                return orginAddress;
            }
            set
            {
                if(value == null)
                {
                    throw new ArgumentOutOfRangeException("invalid! Cannot be null");
                }
                else
                {
                    orginAddress = value;
                }
            }

        }
        public Address DestinationAddress//specifies destination address and what it corresponds to.
        {
            get
            {
                return destinationAddress;

            }
            set
            {
                if(value== null)
                {
                    throw new ArgumentOutOfRangeException("Invalid! cannot be null");
                }
                else
                {
                    destinationAddress = value;
                }
            }
        }
        public abstract decimal CalcCost();

        public override string ToString()//Tostring that overrides original string to provide cost.
        {
            return $"Origin address is: {OrginAddress}\n Destination address is: {DestinationAddress}\n Total Cost:{CalcCost():C2}";
        }


    }
    public class Address//class that specifies whats included in the address fields.
    {

        private string name;
        private string address1;
        private string address2;
        private string city;
        private string state; 
        private int zip;


        public Address(string name, string addressline1, string addressline2, string city, string state, int zip)
        {
            Name = name;
            Address1 = addressline1;
            Address2 = addressline2;
            City = city;
            State = state;
            Zip = zip;


        }

        public Address(string name, string addressline1, string city, string state, int zip)
        {
            Name = name;
            Address1 = addressline1;
            City = city;
            State = state;
            Zip = zip;

        }
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                if(string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(" Invalid! cannot be empty, null or only white space charactes");

                }
                else
                {
                    name = value;
                }
            }
        }
        public string Address1
        {
            get
            {
                return address1;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(" Invalid! cannot be empty, null or only white space charactes");

                }
                else
                {
                    address1 = value;
                }
            }
        }
        public string City
        {
            get
            {
                return city;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(" Invalid! cannot be empty, null or only white space charactes");

                }
                else
                {
                    city = value;
                }
            }
        }
        public string State
        {
            get
            {
                return state;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(" Invalid! cannot be empty, null or only white space charactes");

                }
                else
                {
                    state = value;
                }
            }
        }
        public string Address2
        {
            get
            {
                return address1;
            }
            set
            {
                address1 = value;
            }
        }
        public int Zip
        {
            get
            {
                return zip;
            }
            set
            {
                if (value >= 0 || value <= 99999)
                {
                    zip = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("invalid zipcode");
                }

                
            }
        }
        public override string ToString()
        {
            return $"Name:{Name}\n Address 1: {Address1}\n Address 2: {Address2}\n City:{City} State:{State} Zipcode:{Zip}";
        }

    }
    public class Letter: Parcel// Letter class tht derives from parcell that includes fixed/total cost.
    {
        
        
        private decimal fixedCost;
        

        public Letter(Address orginAddress, Address destinationAddress, decimal fixedCost): base(orginAddress,destinationAddress)
        {
            
            FixedCost = fixedCost;
        }
        private decimal FixedCost
        {
            get
            {
                return fixedCost;
            }
            set
            {
                if(value < 0)
                {
                    throw new ArgumentOutOfRangeException("Invalid number! only positive numbers allowed");
                }
                else
                {
                    fixedCost = value;
                }
            }
        }
        public override decimal CalcCost()
        {
            return fixedCost;
        }
        public override string ToString()
        {
            string NL = Environment.NewLine;
            return $"{NL}{base.ToString()}";
        }
    }
}
