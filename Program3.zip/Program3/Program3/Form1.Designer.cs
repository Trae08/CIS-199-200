﻿
namespace Program3
{
    partial class uPickItGroceryCost
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Farmlbl = new System.Windows.Forms.Label();
            this.Itemlbl = new System.Windows.Forms.Label();
            this.Quantitylbl = new System.Windows.Forms.Label();
            this.Discountedlbl = new System.Windows.Forms.Label();
            this.Shipmentlbl = new System.Windows.Forms.Label();
            this.TotalCostlbl = new System.Windows.Forms.Label();
            this.IntitialCostlbl = new System.Windows.Forms.Label();
            this.farmcombobox = new System.Windows.Forms.ComboBox();
            this.InitalCostoutput = new System.Windows.Forms.Label();
            this.TotalCostOutput = new System.Windows.Forms.Label();
            this.Shipmentoutput = new System.Windows.Forms.Label();
            this.Discountoutput = new System.Windows.Forms.Label();
            this.Itemtxt = new System.Windows.Forms.TextBox();
            this.Poundstxt = new System.Windows.Forms.TextBox();
            this.Calc_btn = new System.Windows.Forms.Button();
            this.Clearbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Farmlbl
            // 
            this.Farmlbl.AutoSize = true;
            this.Farmlbl.Location = new System.Drawing.Point(135, 67);
            this.Farmlbl.Name = "Farmlbl";
            this.Farmlbl.Size = new System.Drawing.Size(33, 13);
            this.Farmlbl.TabIndex = 0;
            this.Farmlbl.Text = "Farm:";
            // 
            // Itemlbl
            // 
            this.Itemlbl.AutoSize = true;
            this.Itemlbl.Location = new System.Drawing.Point(135, 102);
            this.Itemlbl.Name = "Itemlbl";
            this.Itemlbl.Size = new System.Drawing.Size(30, 13);
            this.Itemlbl.TabIndex = 1;
            this.Itemlbl.Text = "Item:";
            // 
            // Quantitylbl
            // 
            this.Quantitylbl.AutoSize = true;
            this.Quantitylbl.Location = new System.Drawing.Point(94, 140);
            this.Quantitylbl.Name = "Quantitylbl";
            this.Quantitylbl.Size = new System.Drawing.Size(80, 13);
            this.Quantitylbl.TabIndex = 2;
            this.Quantitylbl.Text = "Quantity  ( lbs ):";
            // 
            // Discountedlbl
            // 
            this.Discountedlbl.AutoSize = true;
            this.Discountedlbl.Location = new System.Drawing.Point(77, 283);
            this.Discountedlbl.Name = "Discountedlbl";
            this.Discountedlbl.Size = new System.Drawing.Size(88, 13);
            this.Discountedlbl.TabIndex = 3;
            this.Discountedlbl.Text = "Discounted Cost:";
            // 
            // Shipmentlbl
            // 
            this.Shipmentlbl.AutoSize = true;
            this.Shipmentlbl.Location = new System.Drawing.Point(87, 322);
            this.Shipmentlbl.Name = "Shipmentlbl";
            this.Shipmentlbl.Size = new System.Drawing.Size(78, 13);
            this.Shipmentlbl.TabIndex = 4;
            this.Shipmentlbl.Text = "Shipment Cost:";
            // 
            // TotalCostlbl
            // 
            this.TotalCostlbl.AutoSize = true;
            this.TotalCostlbl.Location = new System.Drawing.Point(107, 362);
            this.TotalCostlbl.Name = "TotalCostlbl";
            this.TotalCostlbl.Size = new System.Drawing.Size(61, 13);
            this.TotalCostlbl.TabIndex = 5;
            this.TotalCostlbl.Text = "Total Price:";
            // 
            // IntitialCostlbl
            // 
            this.IntitialCostlbl.AutoSize = true;
            this.IntitialCostlbl.Location = new System.Drawing.Point(107, 247);
            this.IntitialCostlbl.Name = "IntitialCostlbl";
            this.IntitialCostlbl.Size = new System.Drawing.Size(58, 13);
            this.IntitialCostlbl.TabIndex = 6;
            this.IntitialCostlbl.Text = "Initial Cost:";
            // 
            // farmcombobox
            // 
            this.farmcombobox.FormattingEnabled = true;
            this.farmcombobox.Location = new System.Drawing.Point(176, 64);
            this.farmcombobox.Name = "farmcombobox";
            this.farmcombobox.Size = new System.Drawing.Size(121, 21);
            this.farmcombobox.TabIndex = 7;
            this.farmcombobox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // InitalCostoutput
            // 
            this.InitalCostoutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.InitalCostoutput.Location = new System.Drawing.Point(176, 238);
            this.InitalCostoutput.Name = "InitalCostoutput";
            this.InitalCostoutput.Size = new System.Drawing.Size(121, 22);
            this.InitalCostoutput.TabIndex = 10;
            // 
            // TotalCostOutput
            // 
            this.TotalCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalCostOutput.Location = new System.Drawing.Point(176, 361);
            this.TotalCostOutput.Name = "TotalCostOutput";
            this.TotalCostOutput.Size = new System.Drawing.Size(121, 22);
            this.TotalCostOutput.TabIndex = 11;
            // 
            // Shipmentoutput
            // 
            this.Shipmentoutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Shipmentoutput.Location = new System.Drawing.Point(176, 321);
            this.Shipmentoutput.Name = "Shipmentoutput";
            this.Shipmentoutput.Size = new System.Drawing.Size(121, 22);
            this.Shipmentoutput.TabIndex = 12;
            // 
            // Discountoutput
            // 
            this.Discountoutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Discountoutput.Location = new System.Drawing.Point(176, 274);
            this.Discountoutput.Name = "Discountoutput";
            this.Discountoutput.Size = new System.Drawing.Size(121, 22);
            this.Discountoutput.TabIndex = 13;
            // 
            // Itemtxt
            // 
            this.Itemtxt.Location = new System.Drawing.Point(176, 102);
            this.Itemtxt.Name = "Itemtxt";
            this.Itemtxt.Size = new System.Drawing.Size(121, 20);
            this.Itemtxt.TabIndex = 14;
            // 
            // Poundstxt
            // 
            this.Poundstxt.Location = new System.Drawing.Point(176, 137);
            this.Poundstxt.Name = "Poundstxt";
            this.Poundstxt.Size = new System.Drawing.Size(121, 20);
            this.Poundstxt.TabIndex = 15;
            // 
            // Calc_btn
            // 
            this.Calc_btn.Location = new System.Drawing.Point(147, 189);
            this.Calc_btn.Name = "Calc_btn";
            this.Calc_btn.Size = new System.Drawing.Size(89, 32);
            this.Calc_btn.TabIndex = 16;
            this.Calc_btn.Text = "Calculate";
            this.Calc_btn.UseVisualStyleBackColor = true;
            this.Calc_btn.Click += new System.EventHandler(this.Calc_btn_Click);
            // 
            // Clearbtn
            // 
            this.Clearbtn.Location = new System.Drawing.Point(255, 189);
            this.Clearbtn.Name = "Clearbtn";
            this.Clearbtn.Size = new System.Drawing.Size(84, 32);
            this.Clearbtn.TabIndex = 17;
            this.Clearbtn.Text = "Clear";
            this.Clearbtn.UseVisualStyleBackColor = true;
            this.Clearbtn.Click += new System.EventHandler(this.Clearbtn_Click);
            // 
            // uPickItGroceryCost
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Clearbtn);
            this.Controls.Add(this.Calc_btn);
            this.Controls.Add(this.Poundstxt);
            this.Controls.Add(this.Itemtxt);
            this.Controls.Add(this.Discountoutput);
            this.Controls.Add(this.Shipmentoutput);
            this.Controls.Add(this.TotalCostOutput);
            this.Controls.Add(this.InitalCostoutput);
            this.Controls.Add(this.farmcombobox);
            this.Controls.Add(this.IntitialCostlbl);
            this.Controls.Add(this.TotalCostlbl);
            this.Controls.Add(this.Shipmentlbl);
            this.Controls.Add(this.Discountedlbl);
            this.Controls.Add(this.Quantitylbl);
            this.Controls.Add(this.Itemlbl);
            this.Controls.Add(this.Farmlbl);
            this.Name = "uPickItGroceryCost";
            this.Text = "uPickIt Grocery Cost";
            this.Load += new System.EventHandler(this.uPickItGroceryCost_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Farmlbl;
        private System.Windows.Forms.Label Itemlbl;
        private System.Windows.Forms.Label Quantitylbl;
        private System.Windows.Forms.Label Discountedlbl;
        private System.Windows.Forms.Label Shipmentlbl;
        private System.Windows.Forms.Label TotalCostlbl;
        private System.Windows.Forms.Label IntitialCostlbl;
        private System.Windows.Forms.ComboBox farmcombobox;
        private System.Windows.Forms.Label InitalCostoutput;
        private System.Windows.Forms.Label TotalCostOutput;
        private System.Windows.Forms.Label Shipmentoutput;
        private System.Windows.Forms.Label Discountoutput;
        private System.Windows.Forms.TextBox Itemtxt;
        private System.Windows.Forms.TextBox Poundstxt;
        private System.Windows.Forms.Button Calc_btn;
        private System.Windows.Forms.Button Clearbtn;
    }
}

