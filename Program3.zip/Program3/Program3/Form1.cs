﻿// Grading ID: S1345
//CIS 199-02
//Due Date: 4-1-2021
//This program calculates the cost per item and farm while considering the discount and shipment fees.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program3
{
    public partial class uPickItGroceryCost : Form
    {
        
        string[] Farm = { "NE", "NW", "SE", "SW" };//array declaring all farms
        double[] ShipmentFee = { .06, .0717, .07, .0874 };//array of all shipment fees
        double[] CostPerPound = { 7.87, 9.51, 10.73, 9.99, 11.99, 5.00, 4.58 };//array of all cost per pound
        double[] itemNumber = { 10001, 10002, 10003, 10004, 10005, 10006, 10007 };//array list of the item numbers
        double[] Poundlowlimits = { 0, 6, 11, 21 };//Pounds array starting from the lower values
        double[] Discount = { 0, .05, .10, .15 };//discounts per pound array
        double totalcost;//calulates the total cost
        double ShipmentFee1 = 0, ItemNumber1, CostPerPound1 = 0, Pounds, Discount1=0,  InitialCost, ShipmentCost, DiscountCost;// all the calculation variables used in validation

        private void Clearbtn_Click(object sender, EventArgs e)
        {
            farmcombobox.Text = string.Empty;
            Itemtxt.Clear();
            Poundstxt.Clear();
            InitalCostoutput.Text = string.Empty;
            Discountoutput.Text = string.Empty;
            Shipmentoutput.Text = string.Empty;
            TotalCostOutput.Text = string.Empty;
        }

        bool itemFound = false;
        bool FarmFound = false;
        bool quantityFound = false;

        public uPickItGroceryCost()
        {
            InitializeComponent();
        }

        private void uPickItGroceryCost_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < Farm.Length; i++)
            {
                farmcombobox.Items.Add(Farm[i]);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void Calc_btn_Click(object sender, EventArgs e)
        {

            //combobox, Items/item number, & pounds validation
            if (farmcombobox.SelectedIndex >= 0)
            {

                if (double.TryParse(Itemtxt.Text, out ItemNumber1) && ItemNumber1 >= 0)
                {

                    if (double.TryParse(Poundstxt.Text, out Pounds) && Pounds >= 0)
                    {

                        FarmFound = false;
                        for (int i = 0; i < Farm.Length && !FarmFound; ++i)
                        {
                            if(Farm[i]==farmcombobox.Text)
                            {
                                FarmFound = true;
                                ShipmentFee1 = ShipmentFee[i];

                            }
                        }
                        itemFound = false;
                        for (int i = 0; i < itemNumber.Length && !itemFound; ++i)
                        {
                             if(itemNumber[i]== ItemNumber1)
                            {
                                itemFound = true;
                                CostPerPound1 = CostPerPound[i];
                            }
                        }
                        quantityFound = false;
                        int index = Poundlowlimits.Length - 1;
                        while (index >= 0 && !quantityFound)
                        {
                            if(Pounds>= Poundlowlimits[index])
                            {
                                quantityFound = true;
                            }
                            else
                            {
                                --index;
                            }
                        }
                        if(quantityFound)
                        {
                            Discount1 = Discount[index];
                        }
                        //Cost calculations
                        InitialCost = CostPerPound1 * Pounds;

                        DiscountCost = InitialCost-(InitialCost * Discount1);

                        ShipmentCost = DiscountCost * ShipmentFee1;

                        totalcost =  DiscountCost + ShipmentCost;
                        //Currency formats for output values
                        TotalCostOutput.Text = $"{totalcost:C}";
                        InitalCostoutput.Text = $"{InitialCost:C}";
                        Shipmentoutput.Text = $"{ShipmentCost:C}";
                        Discountoutput.Text = $"{DiscountCost:C}";

                    }
                    else
                    {
                        MessageBox.Show(" Invalid Pound Number ");//message boxes for invalid inputs
                    }


                }
                else
                {
                    MessageBox.Show(" Invalid Item Number ");
                }


            }
            else
            {
                MessageBox.Show(" Invalid Farm Selection ");
            }









                        
                   

























               
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                















            
               

            
               





        }
    }
}
