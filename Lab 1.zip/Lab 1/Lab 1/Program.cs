﻿// Lab 1
// CIS 199-01
// Due: 1/24/2021
// By: Lamontra Peters  (Grading ID:   S1345)

//This program displays my grading ID,
//hobbies, favorite book and movie to the console.

using System;

namespace Lab_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Grading ID:     S1345"); //This is my grading ID.
            Console.WriteLine("Hobbies:        Playing Videogames,Hiking,Playing Baskeball"); //Some of the hobbies i do on my spare time.
            Console.WriteLine("Favorite Book:  Hunger Games");//This is my favorite book, well one of them.
            Console.WriteLine("Favorite Movie: Guardians Of The Galaxy"); //This is my favorite movie.
            
           
         
            
            
            
            
          
        }

    }
}
