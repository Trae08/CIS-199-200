﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Program4
{
    class RepairRecord
    {
        //list of all the constant variable assoicated with default and max values.
        const int MinZip = 00000;
        const int MaxZip = 99999;
        const int DefualtZip = 40204;
        const string Defaultmake = "Unknown make or model";
        const string Defaultserialnumber = "A000000000";
        const string Defaulttechname = "John Smith";
        const int Minlength = 15, Maxlength = 180, Defaultlength = 30;
        //all backing fields listed
        private int _zipcode;
        private string _make;
        private string _serialnumber;
        private int _year;
        private int _length;
        private string _techname;
        private bool _warranty;

        public RepairRecord(int zipcode_, string make_, string serialnumber_, int year, int length_, string techname_, bool warranty_)
        {
            //all the backing fields set to a property name
            ZipCode = zipcode_;
            Make = make_;
            SerialNumber = serialnumber_;
            Year = year;
            AppointmentLength = length_;
            Techname = techname_;
            Warranty = warranty_;
           
        }
        //list of all properties with get, set validation.
       public int ZipCode
        {

            get
            {
                return _zipcode;
            }

            set
            {
                if (value > MinZip && value < MaxZip)
                    _zipcode = value;
                else
                    _zipcode = DefualtZip;
            }

        }
       public string Make
        {
            get
            {
                return _make;
            }

            set
            {

                if (String.IsNullOrWhiteSpace(value))
                    _make = Defaultmake;
                else
                    _make = value;
            }
        }


        public string SerialNumber
        {
            get
            {
                return _serialnumber;
            }


            set
            {
                if (value.Length == 10)
                {
                    
                        _serialnumber = value;
                }
                else
                    _serialnumber = Defaultserialnumber;
            }
        }
        public int Year
        {
            get;

            set;
        }



       public int AppointmentLength
        {
            get
            {
                return _length;
            }
            set
            {
                if (value >= Minlength && value <= Maxlength)
                    _length = value;
                else
                    _length = Defaultlength;
            }
        }

        public string Techname
        {
            get
            {
                return _techname;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    _techname = Defaulttechname;
                else
                    _techname = value;

            }
        }

       public bool Warranty
        {
            get; set;
        }
        public double AppointmentHours
        {  
            get
            {
                double convert = 60;
                return AppointmentLength / convert;
            }
        }
        //method displaying the warranty price with validation 
        public double Calccost()
        {
            double Warrantyflatfee = 25;
            double WithWarranty = 20;
            double Variablefee = 1.50;
            if (Warranty == false)
            {
                double Cost = Warrantyflatfee + Variablefee * AppointmentLength;
                 return Cost;
                

            }
            else
            {
                return WithWarranty;
            }
        }

        public override string ToString()
        {
            //return base.ToString(); method with new lines for every statement.
            return  ($"Zip Code: {ZipCode}" + Environment.NewLine
                + $"Make And Model: {Make}" + Environment.NewLine
                + $"Serial Number: {SerialNumber}" + Environment.NewLine
                + $"Year: {Year}" + Environment.NewLine
                + $"Length: {AppointmentLength}" + Environment.NewLine +
                $"Tech Name: {Techname}" + Environment.NewLine +
                $"Warranty: {Warranty}"+Environment.NewLine+
                 $"Appointment Hours: {AppointmentHours}");
            
                
        }
    }
}
