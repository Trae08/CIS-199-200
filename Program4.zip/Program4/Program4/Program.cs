﻿// Grading ID: S1345
//CIS199-02
//Due Date:04/18/2021
//The application shows how to create a repair record using two classes and also display modifications.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    class Program
    {
        static void Main(string[] args)//6 test arrays using Repair record method.
        {

            RepairRecord Car1 = new RepairRecord(41051, "Ford F150", "C493768459", 2011, 45, "Bob Jones", false);
            RepairRecord Car2 = new RepairRecord(40203, "Toyota Matrix", "C857395785", 2005, 60, "Monica Fitzgerald", true);
            RepairRecord Car3 = new RepairRecord(40202, "Tesla Model 3", "C583953958", 2019, 15, "Bob Jones", false);
            RepairRecord Car4 = new RepairRecord(40208, "Mclaren F1", "C968486749", 2500, 120, "Mike Lewis", true);
            RepairRecord Car5 = new RepairRecord(40212, "Gallifreyan Tardis", "C968857575", 2500, 150, "The Doctor", true);
            RepairRecord Car6 = new RepairRecord(40211, "Correllian Tie Fighter", "C565756555", 3600, 80, "Luke Skywalker", false);


            RepairRecord[] Cars = { Car1, Car2, Car3, Car4, Car5, Car6 };//array of your test data
              OutputRepairRecord(Cars);
            //list of the modifications to the initial 6 arrays.
            Cars[0].AppointmentLength=130;
            Cars[1].Make="Kia Soul";
            Cars[2].SerialNumber = "C850169043";
            Cars[3].ZipCode = 40216;
            Cars[4].Techname = "Johnny Cash";
            Cars[5].AppointmentLength = 200;
            Console.WriteLine("\nUpdated details are: ");
            OutputRepairRecord(Cars);



        }
        //output method to display the information as it relates to the arrays in Main.
        public static void OutputRepairRecord(RepairRecord[] Cars)
        {
            for (int i = 0; i < Cars.Length; ++i)
            {
                Console.WriteLine(Cars[i].ToString());
                Console.WriteLine($"Output Cost:{Cars[i]. Calccost()}");
            }
        }
    }
}
