﻿// Grading ID: S1345
// lab 3
// Due Date: 2/14/2021
//CIS199-02
//program calculate area, volume and diameter based on user input of the radius.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // This Calculation button creates a calculation for diameter, area, and volume based on user input for radius.
        private void Calcbtn_Click(object sender, EventArgs e)
        {

            double radius,// declaring all the variables
                   area,
                   diameter,
                   volume;


            radius = double.Parse(Radiustxt.Text);// declares user input for radius.

            area = 4 * Math.PI * Math.Pow(radius, 2);//formula to calculate area.
            diameter = 2 * radius;//formula to calculate the diameter.
            volume = 4 * Math.PI * Math.Pow(radius, 3) / 3;//calculated formula for diameter.

            Diameteroutputlbl.Text = $"{diameter:F2}";//formats output label for diameter with 2 digits of precision.
            SurfaceAreaoutputlbl.Text = $"{area:F2}";//formats area output labal with 2 digits of precision.
            Volumeoutputlbl.Text = $"{volume:F2}";//formats volume output with 2 digits of precision.

        }
    }
}
