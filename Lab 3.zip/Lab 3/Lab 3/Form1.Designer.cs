﻿
namespace Lab_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Radius = new System.Windows.Forms.Label();
            this.Radiustxt = new System.Windows.Forms.TextBox();
            this.Diameter = new System.Windows.Forms.Label();
            this.Area = new System.Windows.Forms.Label();
            this.Volume = new System.Windows.Forms.Label();
            this.Diameteroutputlbl = new System.Windows.Forms.Label();
            this.SurfaceAreaoutputlbl = new System.Windows.Forms.Label();
            this.Volumeoutputlbl = new System.Windows.Forms.Label();
            this.Calcbtn = new System.Windows.Forms.Button();
            this.SpherePicture1 = new System.Windows.Forms.PictureBox();
            this.SpherePicture2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.SpherePicture1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SpherePicture2)).BeginInit();
            this.SuspendLayout();
            // 
            // Radius
            // 
            this.Radius.AutoSize = true;
            this.Radius.Location = new System.Drawing.Point(175, 57);
            this.Radius.Name = "Radius";
            this.Radius.Size = new System.Drawing.Size(90, 13);
            this.Radius.TabIndex = 0;
            this.Radius.Text = "Radius of sphere:";
            // 
            // Radiustxt
            // 
            this.Radiustxt.Location = new System.Drawing.Point(272, 57);
            this.Radiustxt.Name = "Radiustxt";
            this.Radiustxt.Size = new System.Drawing.Size(100, 20);
            this.Radiustxt.TabIndex = 1;
            // 
            // Diameter
            // 
            this.Diameter.AutoSize = true;
            this.Diameter.Location = new System.Drawing.Point(4, 230);
            this.Diameter.Name = "Diameter";
            this.Diameter.Size = new System.Drawing.Size(64, 13);
            this.Diameter.TabIndex = 2;
            this.Diameter.Text = "     Diameter";
            // 
            // Area
            // 
            this.Area.AutoSize = true;
            this.Area.Location = new System.Drawing.Point(4, 274);
            this.Area.Name = "Area";
            this.Area.Size = new System.Drawing.Size(69, 13);
            this.Area.TabIndex = 3;
            this.Area.Text = "Surface Area";
            // 
            // Volume
            // 
            this.Volume.AutoSize = true;
            this.Volume.Location = new System.Drawing.Point(12, 315);
            this.Volume.Name = "Volume";
            this.Volume.Size = new System.Drawing.Size(51, 13);
            this.Volume.TabIndex = 4;
            this.Volume.Text = "   Volume";
            // 
            // Diameteroutputlbl
            // 
            this.Diameteroutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Diameteroutputlbl.Location = new System.Drawing.Point(84, 220);
            this.Diameteroutputlbl.Name = "Diameteroutputlbl";
            this.Diameteroutputlbl.Size = new System.Drawing.Size(100, 23);
            this.Diameteroutputlbl.TabIndex = 5;
            // 
            // SurfaceAreaoutputlbl
            // 
            this.SurfaceAreaoutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SurfaceAreaoutputlbl.Location = new System.Drawing.Point(84, 264);
            this.SurfaceAreaoutputlbl.Name = "SurfaceAreaoutputlbl";
            this.SurfaceAreaoutputlbl.Size = new System.Drawing.Size(100, 23);
            this.SurfaceAreaoutputlbl.TabIndex = 6;
            // 
            // Volumeoutputlbl
            // 
            this.Volumeoutputlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Volumeoutputlbl.Location = new System.Drawing.Point(84, 305);
            this.Volumeoutputlbl.Name = "Volumeoutputlbl";
            this.Volumeoutputlbl.Size = new System.Drawing.Size(100, 23);
            this.Volumeoutputlbl.TabIndex = 7;
            // 
            // Calcbtn
            // 
            this.Calcbtn.Location = new System.Drawing.Point(287, 92);
            this.Calcbtn.Name = "Calcbtn";
            this.Calcbtn.Size = new System.Drawing.Size(75, 23);
            this.Calcbtn.TabIndex = 8;
            this.Calcbtn.Text = "Calculate";
            this.Calcbtn.UseVisualStyleBackColor = true;
            this.Calcbtn.Click += new System.EventHandler(this.Calcbtn_Click);
            // 
            // SpherePicture1
            // 
            this.SpherePicture1.Image = ((System.Drawing.Image)(resources.GetObject("SpherePicture1.Image")));
            this.SpherePicture1.Location = new System.Drawing.Point(231, 178);
            this.SpherePicture1.Name = "SpherePicture1";
            this.SpherePicture1.Size = new System.Drawing.Size(150, 150);
            this.SpherePicture1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SpherePicture1.TabIndex = 9;
            this.SpherePicture1.TabStop = false;
            // 
            // SpherePicture2
            // 
            this.SpherePicture2.Image = ((System.Drawing.Image)(resources.GetObject("SpherePicture2.Image")));
            this.SpherePicture2.Location = new System.Drawing.Point(12, 25);
            this.SpherePicture2.Name = "SpherePicture2";
            this.SpherePicture2.Size = new System.Drawing.Size(150, 150);
            this.SpherePicture2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SpherePicture2.TabIndex = 10;
            this.SpherePicture2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 361);
            this.Controls.Add(this.SpherePicture2);
            this.Controls.Add(this.SpherePicture1);
            this.Controls.Add(this.Calcbtn);
            this.Controls.Add(this.Volumeoutputlbl);
            this.Controls.Add(this.SurfaceAreaoutputlbl);
            this.Controls.Add(this.Diameteroutputlbl);
            this.Controls.Add(this.Volume);
            this.Controls.Add(this.Area);
            this.Controls.Add(this.Diameter);
            this.Controls.Add(this.Radiustxt);
            this.Controls.Add(this.Radius);
            this.Name = "Form1";
            this.Text = "Lab 3";
            ((System.ComponentModel.ISupportInitialize)(this.SpherePicture1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SpherePicture2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Radius;
        private System.Windows.Forms.TextBox Radiustxt;
        private System.Windows.Forms.Label Diameter;
        private System.Windows.Forms.Label Area;
        private System.Windows.Forms.Label Volume;
        private System.Windows.Forms.Label Diameteroutputlbl;
        private System.Windows.Forms.Label SurfaceAreaoutputlbl;
        private System.Windows.Forms.Label Volumeoutputlbl;
        private System.Windows.Forms.Button Calcbtn;
        private System.Windows.Forms.PictureBox SpherePicture1;
        private System.Windows.Forms.PictureBox SpherePicture2;
    }
}

