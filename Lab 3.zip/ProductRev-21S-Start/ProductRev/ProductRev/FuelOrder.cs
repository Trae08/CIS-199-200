﻿//Grading ID here

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductRev

{
    public class FuelOrder

    {
        private string _description;
        private string _octanerating;
        private int _volume;
        private double _price;
        // #1 - Put needed backing fields here
        // Remember: Some properties may be
        // auto-implemented, so only create
        // backing fields for ones needed

        public string Description
        {
            get;set; // #2 - Put your code here for get/set accessors
            // May be auto-implemented

        }

        public string OctaneRating
        {
            get;set;// #3 - Put your code here for get/set accessors
            // May be auto-implemented

        }

        public int Volume
        {
            get
            {
                return _volume;
            }
            set
            {
                if (value >= 0)
                {
                    _volume = value;
                }
                else
                    value = 0;
            }

            
               // #4 - Put your code here for get/set accessors
            // Set must validate!

        }

        public double Price
        {  
            get
            {
                return _price;
            }
            set
            {
                if(value>=0)
                {
                    _price = value;
                }
                else
                {
                    value = 0;
                }
            }
            
                // #5 - Put your code here for get/set accessors
            // Set must validate!

        }

        public FuelOrder(string desc, string octaneRating, double volume, double price)
        {
            Description = _description;
            OctaneRating = _octanerating;
            Volume = _volume;
            Price = _price;
            // #6 - Put your code here for constructor
            // Be sure your parameters get validated through properties

        }

        public double CalcFuelCost()
        {
            double quantity;
            double price;
           return  Volume* Price;
            
            // #7 - Put your code here to calculate value of
            // this item in inventory
            // Example: 2500 @ $4.99 = $12,475

        }

        public override string ToString()
        {
            return ($"Desciprion:{Description}" + ($"OctaneRating:{OctaneRating}" + $"Volume:{Volume}" + $"Price:{Price}"));








               
            // Use format that would produce a string like:
            // "Premium: 92 (25 @ $2.99)"
            // where 92 is the octane rating, Premium is the
            // description, 25 is the volume, and $2.99 is
            // the price. No newlines are needed.


        }
    }
}
