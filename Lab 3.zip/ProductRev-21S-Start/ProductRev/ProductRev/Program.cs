﻿// Grading ID Here

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace ProductRev
{
    class Program
    {
        static void Main(string[] args)
        {
            double currentValue;   // Current product's value
            double totalValue = 0; // Running total of product's value
            FuelOrder[] orders; // Product Items

            // #1 - Put code here to construct 3  Fuel orders
            FuelOrder order1 = new FuelOrder("Premium", "87", 10, 3.25);
            FuelOrder order2 = new FuelOrder("unleaded", "91", 12, 4.50);
            FuelOrder order3 = new FuelOrder("Premium", "94", 8, 2.23);

            orders = new FuelOrder[] { order1, order2, order3 };
            OutputFuelOrder(orders);

            WriteLine($"Product Revenue Report:");
            orders[0].OctaneRating = "94";
            orders[1].Description = "Premium";
            orders[2].Price = 2.55;
            Console.WriteLine("\nUpdated details are: ");
            OutputFuelOrder(orders);
            // #2 - Complete loop to step through array of items
            for (int index = 0; ; ++index)
            {

                currentValue = orders[index].CalcFuelCost(); // #3 - Complete statement to calculate value of current item
                                                             //      from array by calling CalcFuelCost

                totalValue = 

                // #5 - Output currentValue, with currency formatting, followed by string representation
                //      of current item from array
            }

            WriteLine("\nTotal Gross Revenue:");
            // #6 - Output totalValue of Gross Revenue, with currency formatting

        }
    }
}
