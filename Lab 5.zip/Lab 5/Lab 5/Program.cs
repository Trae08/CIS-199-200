﻿//Grading ID: S1345
//CIS199-02
//Due date: 3/7/21
//this program vailidates user input amnd then totals and calculates the mean.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace Lab_5
{
    class Program
    {
        static void Main(string[] args)
        {

            
            
            //declared variables
            const int SENTINEL = 999;//stop variable
            const int Max_Temp = 130;//max temp variable
            const int Min_temp = -20;//min temp
            int count = 0;
            int sum = 0;
            string stringsum;

            double mean;
            int Temp;
            string stringtemp;
            bool vaildTemp;

           WriteLine("Enter temperatures from -20 to 130 (999 to stop)      Enter temperature:   ");
            stringtemp = ReadLine();
           
            vaildTemp = (int.TryParse(ReadLine(), out Temp) && (Temp >= Min_temp && Temp <= Max_Temp));//restriction for user input.
            while (Temp != SENTINEL)
            {
                
                if (vaildTemp )//adds to count  if user inputs valid temperature
                {


                    sum += Temp;
                    ++count;
                   
                }
                else 
                {
                    Console.WriteLine("Valid temperatures range from -20 to 130. Please reenter temperature: ");

                     
                }

                vaildTemp = (int.TryParse(ReadLine(), out Temp) && (Temp >= Min_temp && Temp <= Max_Temp));//reads user input second time

                WriteLine("Enter temperature:  ");
                stringtemp = ReadLine();

                WriteLine("You entered {0} valid temperatures.", count, vaildTemp);// totals all valid inputs
                    stringsum = ReadLine();
                    int.TryParse(stringsum, out sum);

                    mean = sum / count;
                    WriteLine("The mean temperature is {0} degrees.", mean);//calclates the mean based on total and counts
                
                
               
            }   

            














        }
    }
}
