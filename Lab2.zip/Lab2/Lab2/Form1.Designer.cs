﻿
namespace Lab2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MealPrice = new System.Windows.Forms.Label();
            this.MealPriceTxT = new System.Windows.Forms.TextBox();
            this.Tip15 = new System.Windows.Forms.Label();
            this.Tip18 = new System.Windows.Forms.Label();
            this.outputlb18 = new System.Windows.Forms.Label();
            this.outputlb20 = new System.Windows.Forms.Label();
            this.Calcbtn = new System.Windows.Forms.Button();
            this.outputlb15 = new System.Windows.Forms.Label();
            this.Tip20 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // MealPrice
            // 
            this.MealPrice.AutoSize = true;
            this.MealPrice.Location = new System.Drawing.Point(59, 36);
            this.MealPrice.Name = "MealPrice";
            this.MealPrice.Size = new System.Drawing.Size(98, 13);
            this.MealPrice.TabIndex = 0;
            this.MealPrice.Text = "Enter price of meal:";
            this.MealPrice.Click += new System.EventHandler(this.label1_Click);
            // 
            // MealPriceTxT
            // 
            this.MealPriceTxT.Location = new System.Drawing.Point(160, 33);
            this.MealPriceTxT.Name = "MealPriceTxT";
            this.MealPriceTxT.Size = new System.Drawing.Size(100, 20);
            this.MealPriceTxT.TabIndex = 1;
            // 
            // Tip15
            // 
            this.Tip15.AutoSize = true;
            this.Tip15.Location = new System.Drawing.Point(122, 72);
            this.Tip15.Name = "Tip15";
            this.Tip15.Size = new System.Drawing.Size(27, 13);
            this.Tip15.TabIndex = 2;
            this.Tip15.Text = "15%";
            // 
            // Tip18
            // 
            this.Tip18.AutoSize = true;
            this.Tip18.Location = new System.Drawing.Point(122, 111);
            this.Tip18.Name = "Tip18";
            this.Tip18.Size = new System.Drawing.Size(27, 13);
            this.Tip18.TabIndex = 3;
            this.Tip18.Text = "18%";
            // 
            // outputlb18
            // 
            this.outputlb18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlb18.Location = new System.Drawing.Point(160, 111);
            this.outputlb18.Name = "outputlb18";
            this.outputlb18.Size = new System.Drawing.Size(100, 23);
            this.outputlb18.TabIndex = 6;
            // 
            // outputlb20
            // 
            this.outputlb20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlb20.Location = new System.Drawing.Point(160, 147);
            this.outputlb20.Name = "outputlb20";
            this.outputlb20.Size = new System.Drawing.Size(100, 23);
            this.outputlb20.TabIndex = 7;
            // 
            // Calcbtn
            // 
            this.Calcbtn.Location = new System.Drawing.Point(125, 212);
            this.Calcbtn.Name = "Calcbtn";
            this.Calcbtn.Size = new System.Drawing.Size(93, 25);
            this.Calcbtn.TabIndex = 8;
            this.Calcbtn.Text = "Calculate Tip";
            this.Calcbtn.UseVisualStyleBackColor = true;
            this.Calcbtn.Click += new System.EventHandler(this.Calcbtn_Click);
            // 
            // outputlb15
            // 
            this.outputlb15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlb15.Location = new System.Drawing.Point(160, 71);
            this.outputlb15.Name = "outputlb15";
            this.outputlb15.Size = new System.Drawing.Size(100, 23);
            this.outputlb15.TabIndex = 9;
            // 
            // Tip20
            // 
            this.Tip20.AutoSize = true;
            this.Tip20.Location = new System.Drawing.Point(122, 148);
            this.Tip20.Name = "Tip20";
            this.Tip20.Size = new System.Drawing.Size(27, 13);
            this.Tip20.TabIndex = 10;
            this.Tip20.Text = "20%";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(338, 290);
            this.Controls.Add(this.Tip20);
            this.Controls.Add(this.outputlb15);
            this.Controls.Add(this.Calcbtn);
            this.Controls.Add(this.outputlb20);
            this.Controls.Add(this.outputlb18);
            this.Controls.Add(this.Tip18);
            this.Controls.Add(this.Tip15);
            this.Controls.Add(this.MealPriceTxT);
            this.Controls.Add(this.MealPrice);
            this.Name = "Form1";
            this.Text = "Lab2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MealPrice;
        private System.Windows.Forms.TextBox MealPriceTxT;
        private System.Windows.Forms.Label Tip15;
        private System.Windows.Forms.Label Tip18;
        private System.Windows.Forms.Label outputlb18;
        private System.Windows.Forms.Label outputlb20;
        private System.Windows.Forms.Button Calcbtn;
        private System.Windows.Forms.Label outputlb15;
        private System.Windows.Forms.Label Tip20;
    }
}

