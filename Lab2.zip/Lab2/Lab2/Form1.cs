﻿// Grading ID: S1345
// lab 2
//Due Date: 2/7/2021
// CIS199-02
//Program calculates tips of meal prices based on tip percentages 15,18, 20.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
        // This click event multiplies the meal price input by the tip percentages.
        private void Calcbtn_Click(object sender, EventArgs e)
        {
            double MealPrice;//this is the value of the meal price input
            double Tip15;// this declares the variable for 15% on design form
            double Tip18;// this declares the variable for 18% on design form
            double Tip20;// this declares the variable for 20% in design form


            const double Tip15Rate = 0.15;// this defines that 15% is .15 converted to decimal format
            const double Tip18Rate = 0.18;// this defines that 18% is .18 converted to decimal format
            const double Tip20Rate = 0.20;// this defines that 20% is .20 converted to decimal format

            MealPrice = double.Parse(MealPriceTxT.Text);

            Tip15 = MealPrice * Tip15Rate;
            Tip18 = MealPrice * Tip18Rate;
            Tip20 = MealPrice * Tip20Rate;

            outputlb15.Text = String.Format("{0}", Tip15.ToString("C2"));
            outputlb18.Text = String.Format("{0}", Tip18.ToString("C2"));
            outputlb20.Text = String.Format("{0}", Tip20.ToString("C2"));
            MealPriceTxT.Text = $"{MealPrice:F2}";
        }
    }
}
