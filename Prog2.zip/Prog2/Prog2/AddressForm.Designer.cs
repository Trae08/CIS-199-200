﻿
namespace UPVApp
{
    partial class AddressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Nametxt = new System.Windows.Forms.TextBox();
            this.Address1txt = new System.Windows.Forms.TextBox();
            this.Address2txt = new System.Windows.Forms.TextBox();
            this.Citytxt = new System.Windows.Forms.TextBox();
            this.Namelbl = new System.Windows.Forms.Label();
            this.ZipTxt = new System.Windows.Forms.TextBox();
            this.addresslbl = new System.Windows.Forms.Label();
            this.Citylbl = new System.Windows.Forms.Label();
            this.Statelbl = new System.Windows.Forms.Label();
            this.Ziplbl = new System.Windows.Forms.Label();
            this.Statecbox = new System.Windows.Forms.ComboBox();
            this.CancelClickbtn = new System.Windows.Forms.Button();
            this.OKbtn = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider5 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).BeginInit();
            this.SuspendLayout();
            // 
            // Nametxt
            // 
            this.Nametxt.Location = new System.Drawing.Point(79, 35);
            this.Nametxt.Name = "Nametxt";
            this.Nametxt.Size = new System.Drawing.Size(100, 20);
            this.Nametxt.TabIndex = 0;
            this.Nametxt.Validating += new System.ComponentModel.CancelEventHandler(this.name_validating);
            this.Nametxt.Validated += new System.EventHandler(this.name_validated);
            // 
            // Address1txt
            // 
            this.Address1txt.Location = new System.Drawing.Point(79, 61);
            this.Address1txt.Name = "Address1txt";
            this.Address1txt.Size = new System.Drawing.Size(100, 20);
            this.Address1txt.TabIndex = 1;
            this.Address1txt.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            this.Address1txt.Validating += new System.ComponentModel.CancelEventHandler(this.address_validating);
            this.Address1txt.Validated += new System.EventHandler(this.address_validated);
            // 
            // Address2txt
            // 
            this.Address2txt.Location = new System.Drawing.Point(79, 87);
            this.Address2txt.Name = "Address2txt";
            this.Address2txt.Size = new System.Drawing.Size(100, 20);
            this.Address2txt.TabIndex = 2;
            // 
            // Citytxt
            // 
            this.Citytxt.Location = new System.Drawing.Point(79, 123);
            this.Citytxt.Name = "Citytxt";
            this.Citytxt.Size = new System.Drawing.Size(100, 20);
            this.Citytxt.TabIndex = 3;
            this.Citytxt.Validating += new System.ComponentModel.CancelEventHandler(this.City_validating);
            this.Citytxt.Validated += new System.EventHandler(this.City_validated);
            // 
            // Namelbl
            // 
            this.Namelbl.AutoSize = true;
            this.Namelbl.Location = new System.Drawing.Point(25, 38);
            this.Namelbl.Name = "Namelbl";
            this.Namelbl.Size = new System.Drawing.Size(35, 13);
            this.Namelbl.TabIndex = 4;
            this.Namelbl.Text = "Name";
            this.Namelbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // ZipTxt
            // 
            this.ZipTxt.Location = new System.Drawing.Point(79, 174);
            this.ZipTxt.Name = "ZipTxt";
            this.ZipTxt.Size = new System.Drawing.Size(100, 20);
            this.ZipTxt.TabIndex = 5;
            this.ZipTxt.Validating += new System.ComponentModel.CancelEventHandler(this.ZipTxt_Validating);
            this.ZipTxt.Validated += new System.EventHandler(this.ZipTxt_validated);
            // 
            // addresslbl
            // 
            this.addresslbl.AutoSize = true;
            this.addresslbl.Location = new System.Drawing.Point(25, 68);
            this.addresslbl.Name = "addresslbl";
            this.addresslbl.Size = new System.Drawing.Size(45, 13);
            this.addresslbl.TabIndex = 6;
            this.addresslbl.Text = "Address";
            // 
            // Citylbl
            // 
            this.Citylbl.AutoSize = true;
            this.Citylbl.Location = new System.Drawing.Point(25, 123);
            this.Citylbl.Name = "Citylbl";
            this.Citylbl.Size = new System.Drawing.Size(24, 13);
            this.Citylbl.TabIndex = 7;
            this.Citylbl.Text = "City";
            // 
            // Statelbl
            // 
            this.Statelbl.AutoSize = true;
            this.Statelbl.Location = new System.Drawing.Point(25, 155);
            this.Statelbl.Name = "Statelbl";
            this.Statelbl.Size = new System.Drawing.Size(32, 13);
            this.Statelbl.TabIndex = 8;
            this.Statelbl.Text = "State";
            // 
            // Ziplbl
            // 
            this.Ziplbl.AutoSize = true;
            this.Ziplbl.Location = new System.Drawing.Point(25, 177);
            this.Ziplbl.Name = "Ziplbl";
            this.Ziplbl.Size = new System.Drawing.Size(22, 13);
            this.Ziplbl.TabIndex = 9;
            this.Ziplbl.Text = "Zip";
            // 
            // Statecbox
            // 
            this.Statecbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Statecbox.FormattingEnabled = true;
            this.Statecbox.Items.AddRange(new object[] {
            "KY",
            "IN",
            "TN",
            "MI"});
            this.Statecbox.Location = new System.Drawing.Point(79, 147);
            this.Statecbox.Name = "Statecbox";
            this.Statecbox.Size = new System.Drawing.Size(100, 21);
            this.Statecbox.TabIndex = 10;
            this.Statecbox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // CancelClickbtn
            // 
            this.CancelClickbtn.Location = new System.Drawing.Point(41, 226);
            this.CancelClickbtn.Name = "CancelClickbtn";
            this.CancelClickbtn.Size = new System.Drawing.Size(75, 23);
            this.CancelClickbtn.TabIndex = 11;
            this.CancelClickbtn.Text = "Cancel";
            this.CancelClickbtn.UseVisualStyleBackColor = true;
            // 
            // OKbtn
            // 
            this.OKbtn.Location = new System.Drawing.Point(150, 226);
            this.OKbtn.Name = "OKbtn";
            this.OKbtn.Size = new System.Drawing.Size(75, 23);
            this.OKbtn.TabIndex = 12;
            this.OKbtn.Text = "OK";
            this.OKbtn.UseVisualStyleBackColor = true;
            this.OKbtn.Click += new System.EventHandler(this.OKbtn_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // errorProvider5
            // 
            this.errorProvider5.ContainerControl = this;
            // 
            // AddressForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 450);
            this.Controls.Add(this.OKbtn);
            this.Controls.Add(this.CancelClickbtn);
            this.Controls.Add(this.Statecbox);
            this.Controls.Add(this.Ziplbl);
            this.Controls.Add(this.Statelbl);
            this.Controls.Add(this.Citylbl);
            this.Controls.Add(this.addresslbl);
            this.Controls.Add(this.ZipTxt);
            this.Controls.Add(this.Namelbl);
            this.Controls.Add(this.Citytxt);
            this.Controls.Add(this.Address2txt);
            this.Controls.Add(this.Address1txt);
            this.Controls.Add(this.Nametxt);
            this.Name = "AddressForm";
            this.Text = "AddressForm";
            this.Load += new System.EventHandler(this.AddressForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Nametxt;
        private System.Windows.Forms.TextBox Address1txt;
        private System.Windows.Forms.TextBox Address2txt;
        private System.Windows.Forms.TextBox Citytxt;
        private System.Windows.Forms.Label Namelbl;
        private System.Windows.Forms.TextBox ZipTxt;
        private System.Windows.Forms.Label addresslbl;
        private System.Windows.Forms.Label Citylbl;
        private System.Windows.Forms.Label Statelbl;
        private System.Windows.Forms.Label Ziplbl;
        private System.Windows.Forms.ComboBox Statecbox;
        private System.Windows.Forms.Button CancelClickbtn;
        private System.Windows.Forms.Button OKbtn;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.ErrorProvider errorProvider5;
    }
}