﻿//Address form where user data is collected and displayed via the Address List.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class AddressForm : Form
    {
        public AddressForm()
        {
            InitializeComponent();
            Statecbox.Text = "KY";
        }
        //internal inclusion strings for all the values in the form that get and set the values to the textbox.
        internal string AddressName
        {
            get { return Nametxt.Text; }

            set { Nametxt.Text = value; }
        }

        internal string Address
        {
            get { return Address1txt.Text; }

            set { Address1txt.Text = value; }
        }
        internal string Address2
        {
            get { return Address2txt.Text; }

            set { Address2txt.Text = value; }
        }
        internal string City
        {
            get { return Citytxt.Text; }

            set { Citytxt.Text = value; }

        }
        internal string State
        {
            get { return Statecbox.Text; }

            set { Statecbox.Text = value; }
        }
        internal string InputZipValue
        {
            get { return ZipTxt.Text; }

            set { ZipTxt.Text = value; }
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void CancelClickbtn_Click(object sender, MouseEventArgs e)//Validating if the left mouse button was clicked on the Cancel button.
        {
            if (e.Button == MouseButtons.Left)
                this.DialogResult = DialogResult.Cancel;
        }
        private void OKbtn_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        private void AddressForm_Load(object sender, EventArgs e)
        {

        }
        // validation for all fields in the Address form
        private void ZipTxt_Validated(object sender, CancelEventArgs e)
        {
            errorProvider2.SetError(ZipTxt, "");
        }

        private void ZipTxt_Validating(object sender, CancelEventArgs e)// Confirming the integer is non-negative and less than 99999.
        {
            int number;

            if(!int.TryParse(ZipTxt.Text, out number))
            {
                e.Cancel = true;

                errorProvider2.SetError(ZipTxt, "Enter an Integer!");

                ZipTxt.SelectAll();
            }
            else
            {
                if(number < 0)
                {
                    e.Cancel = true;

                    errorProvider2.SetError(ZipTxt, "Enter a non-negative integer!");

                    ZipTxt.SelectAll();
                }
                if(number > 99999)
                {
                    e.Cancel = true;

                    errorProvider2.SetError(ZipTxt, "Enter number less than 99999");

                    ZipTxt.SelectAll();
                }
            }
        }

        private void name_validated(object sender, EventArgs e)
        {
            errorProvider2.Clear();
        }

        private void name_validating(object sender, CancelEventArgs e)
        {
            if(string.IsNullOrEmpty(Nametxt.Text)|| string.IsNullOrWhiteSpace(Nametxt.Text))// string requiring a input if textbox is kept null.
            {
                e.Cancel = true;
                errorProvider2.SetError(Nametxt, " Please Enter a Name");
                Nametxt.SelectAll();

            }
        }

        private void address_validated(object sender, EventArgs e)
        {
            errorProvider2.Clear();// after the error is fixed the error will clear itself.
        }

        private void address_validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(Address1txt.Text) || string.IsNullOrWhiteSpace(Address1txt.Text))
            {
                e.Cancel = true;
                errorProvider2.SetError(Address1txt, " Please Enter a Address");
                Address1txt.SelectAll();

            }
        }

       

        private void City_validated(object sender, EventArgs e)
        {
            errorProvider2.Clear();
        }

        private void City_validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(Citytxt.Text) || string.IsNullOrWhiteSpace(Citytxt.Text))
            {
                e.Cancel = true;
                errorProvider2.SetError(Citytxt, " Please Enter a City");
                Citytxt.SelectAll();

            }
        }

        private void ZipTxt_validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(ZipTxt, "");
        }
    }
}
