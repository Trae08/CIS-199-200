﻿
namespace UPVApp
{
    partial class LetterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CostTxt = new System.Windows.Forms.TextBox();
            this.OrginAdbox = new System.Windows.Forms.ComboBox();
            this.DestAdBox = new System.Windows.Forms.ComboBox();
            this.OriginAddlbl = new System.Windows.Forms.Label();
            this.DestinationAddresslbl = new System.Windows.Forms.Label();
            this.FixedCostlbl = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.Cancelbtn = new System.Windows.Forms.Button();
            this.okbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            this.SuspendLayout();
            // 
            // CostTxt
            // 
            this.CostTxt.Location = new System.Drawing.Point(104, 143);
            this.CostTxt.Name = "CostTxt";
            this.CostTxt.Size = new System.Drawing.Size(100, 20);
            this.CostTxt.TabIndex = 3;
            this.CostTxt.TextChanged += new System.EventHandler(this.CostTxt_TextChanged);
            this.CostTxt.Validating += new System.ComponentModel.CancelEventHandler(this.FixedCost_Validating);
            this.CostTxt.Validated += new System.EventHandler(this.FixedCost_Validated);
            // 
            // OrginAdbox
            // 
            this.OrginAdbox.FormattingEnabled = true;
            this.OrginAdbox.Location = new System.Drawing.Point(104, 32);
            this.OrginAdbox.Name = "OrginAdbox";
            this.OrginAdbox.Size = new System.Drawing.Size(100, 21);
            this.OrginAdbox.TabIndex = 0;
            this.OrginAdbox.Validating += new System.ComponentModel.CancelEventHandler(this.orginAD_validating);
            this.OrginAdbox.Validated += new System.EventHandler(this.orginAD_validated);
            // 
            // DestAdBox
            // 
            this.DestAdBox.FormattingEnabled = true;
            this.DestAdBox.Location = new System.Drawing.Point(104, 85);
            this.DestAdBox.Name = "DestAdBox";
            this.DestAdBox.Size = new System.Drawing.Size(100, 21);
            this.DestAdBox.TabIndex = 1;
            this.DestAdBox.Validating += new System.ComponentModel.CancelEventHandler(this.desAD_validating);
            this.DestAdBox.Validated += new System.EventHandler(this.desAD_validated);
            // 
            // OriginAddlbl
            // 
            this.OriginAddlbl.AutoSize = true;
            this.OriginAddlbl.Location = new System.Drawing.Point(12, 32);
            this.OriginAddlbl.Name = "OriginAddlbl";
            this.OriginAddlbl.Size = new System.Drawing.Size(72, 13);
            this.OriginAddlbl.TabIndex = 3;
            this.OriginAddlbl.Text = "OriginAddress";
            // 
            // DestinationAddresslbl
            // 
            this.DestinationAddresslbl.AutoSize = true;
            this.DestinationAddresslbl.Location = new System.Drawing.Point(0, 93);
            this.DestinationAddresslbl.Name = "DestinationAddresslbl";
            this.DestinationAddresslbl.Size = new System.Drawing.Size(98, 13);
            this.DestinationAddresslbl.TabIndex = 4;
            this.DestinationAddresslbl.Text = "DestinationAddress";
            // 
            // FixedCostlbl
            // 
            this.FixedCostlbl.AutoSize = true;
            this.FixedCostlbl.Location = new System.Drawing.Point(12, 150);
            this.FixedCostlbl.Name = "FixedCostlbl";
            this.FixedCostlbl.Size = new System.Drawing.Size(56, 13);
            this.FixedCostlbl.TabIndex = 5;
            this.FixedCostlbl.Text = "Fixed Cost";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // Cancelbtn
            // 
            this.Cancelbtn.Location = new System.Drawing.Point(15, 190);
            this.Cancelbtn.Name = "Cancelbtn";
            this.Cancelbtn.Size = new System.Drawing.Size(75, 23);
            this.Cancelbtn.TabIndex = 6;
            this.Cancelbtn.Text = "Cancel";
            this.Cancelbtn.UseVisualStyleBackColor = true;
            // 
            // okbtn
            // 
            this.okbtn.Location = new System.Drawing.Point(172, 190);
            this.okbtn.Name = "okbtn";
            this.okbtn.Size = new System.Drawing.Size(75, 23);
            this.okbtn.TabIndex = 7;
            this.okbtn.Text = "OK";
            this.okbtn.UseVisualStyleBackColor = true;
            this.okbtn.Click += new System.EventHandler(this.okbtn_Click);
            // 
            // LetterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 450);
            this.Controls.Add(this.okbtn);
            this.Controls.Add(this.Cancelbtn);
            this.Controls.Add(this.FixedCostlbl);
            this.Controls.Add(this.DestinationAddresslbl);
            this.Controls.Add(this.OriginAddlbl);
            this.Controls.Add(this.DestAdBox);
            this.Controls.Add(this.OrginAdbox);
            this.Controls.Add(this.CostTxt);
            this.Name = "LetterForm";
            this.Text = "LetterForm";
            this.Load += new System.EventHandler(this.LetterForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox CostTxt;
        private System.Windows.Forms.ComboBox OrginAdbox;
        private System.Windows.Forms.ComboBox DestAdBox;
        private System.Windows.Forms.Label OriginAddlbl;
        private System.Windows.Forms.Label DestinationAddresslbl;
        private System.Windows.Forms.Label FixedCostlbl;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.Button okbtn;
        private System.Windows.Forms.Button Cancelbtn;
    }
}