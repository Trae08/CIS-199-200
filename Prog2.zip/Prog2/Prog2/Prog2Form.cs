﻿//This form collects all user inputs and displays data accordingly.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class Prog2Form : Form
    {
        private UserParcelView upv;
        public Prog2Form()
        {
            // List of test parcel/letter data
            InitializeComponent();
            upv = new UserParcelView();

            upv.AddAddress("Mike Tyson", "233 KnockOut Way", " Apt. 23 ",
                "Louisville", "KY", 40218);
            upv.AddAddress("John Doe", "111 Market St.",
                "Jeffersonville", "IN", 47130);
            upv.AddAddress("Johnny Cage", " 321 kombat St. ", "suite 67", 
                " Corydon", "IN", 47112);
            upv.AddAddress("John Cena", " U Can See Me Dr.",
                "Louisville", "KY", 40215);
            upv.AddAddress("Scooby-Doo", "543 Where R U Dr.", 
                " Spooky City", "TN", 37210);
            upv.AddAddress("Micheal Myers", " 1031 Stabbers Road", "Apt.19",
                "Mask-Up City", "MI", 63110);
            upv.AddAddress("Sub-Zero", "178 Freezer Lane",
                " Jeffersonville", "IN", 47228);
            upv.AddAddress("Mark Cuban", "1001 Cash Out Avenue", "Suite 852", 
                "Nashville", "TN", 37364);


            upv.AddLetter(upv.AddressAt(0), upv.AddressAt(1), 3.85M);
            upv.AddLetter(upv.AddressAt(2), upv.AddressAt(3), 4.25M);
            upv.AddGroundPackage(upv.AddressAt(4), upv.AddressAt(5), 14, 10, 3, 10.2);
            upv.AddGroundPackage(upv.AddressAt(6), upv.AddressAt(7), 2.4, 5.5, 7, 8.1);
            upv.AddNextDayAirPackage(upv.AddressAt(0), upv.AddressAt(3), 15, 32, 25, 67, 3.50M);
            upv.AddNextDayAirPackage(upv.AddressAt(4), upv.AddressAt(2), 5, 2.5, 5, 2, 1.25M);
            upv.AddTwoDayAirPackage(upv.AddressAt(5), upv.AddressAt(6), 10, 15, 7, 30, TwoDayAirPackage.Delivery.Early);
            upv.AddTwoDayAirPackage(upv.AddressAt(7), upv.AddressAt(6), 9, 15, 45, 25,TwoDayAirPackage.Delivery.Saver);
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)// displays what the program is about and relative information.
        {
            MessageBox.Show(" Grading ID: 5126336\n CIS 200-50\n Program 2\n Due Date: 10/25/2021  ");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)//Executes the application.
        {
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)// User cannot change the display textbox.
        {
            MainForm.ReadOnly = true;
        }

        
        
                    

            
                

        private void Prog2Form_Load(object sender, EventArgs e)
        {
            
        }
        //Formattion of the drop down menus in the main prog2 form.
        private void addressListToolStripMenuItem_Click_1(object sender, EventArgs e)//complies user data to be displayed once Adress is clicked.
        {
            var addressList = new StringBuilder();
            addressList.Append("Address").AppendLine().AppendLine();

            foreach (Address a in upv.AddressList)
            {
                addressList.Append(a.ToString()).AppendLine();
                addressList.Append("----------------------").AppendLine();
            }
            MainForm.Text = addressList.ToString();
        }

        private void Addressmenu_Click(object sender, EventArgs e)//Formats the Adress dropdown button to display Address form
        {
            AddressForm addressForm = new AddressForm();
            DialogResult result;
            int zip;
            result = addressForm.ShowDialog();

            if(result == DialogResult.OK)
            {
                zip = int.Parse(addressForm.InputZipValue);
                upv.AddAddress(addressForm.AddressName, addressForm.Address, addressForm.Address2, addressForm.City, addressForm.State, zip);
            }

        }

        private void Lettermenu_Click(object sender, EventArgs e)//Formats the Letter dropdown button to display Letter form
        {
            LetterForm letterForm = new LetterForm(upv.AddressList);
            DialogResult result;
            decimal fixedCost;
            int OriginAdd;
            int DestAdd;
            result = letterForm.ShowDialog();

            if(result == DialogResult.OK)
            {
                OriginAdd = letterForm.OriginAdd;
                DestAdd = letterForm.DestinationAdd;
                fixedCost = int.Parse(letterForm.fixedCost);
                upv.AddLetter(upv.AddressAt(OriginAdd), upv.AddressAt(DestAdd), fixedCost);

            }
        }

        private void letterListToolStripMenuItem_Click(object sender, EventArgs e)// displayed complied user data gathered from the letter form and displays related data.
        {
            
            var letterList = new StringBuilder();
            decimal totalCos = 0;

            letterList.Append("Parcel").AppendLine().AppendLine();

            foreach(Parcel p in upv.ParcelList)
            {
                letterList.Append(p.ToString()).AppendLine();
                letterList.Append("-----------------------").AppendLine();
                totalCos += p.CalcCost();
            }

            MainForm.Text = letterList.ToString();
            MainForm.Text += $" Total Cost: {totalCos:C2}";
        }
    }
}
