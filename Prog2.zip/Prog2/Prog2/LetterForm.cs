﻿//Creates a new Letter based on user input and transfers data to the report for display.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class LetterForm : Form
    {
        // internal strings that include from where they relate of the design form.
        private List<Address> addressList;
        public LetterForm(List<Address>addresses)
        {
            InitializeComponent();
            addressList = addresses;
        }
        internal int OriginAdd
        {
            get { return OrginAdbox.SelectedIndex; }
            set { OrginAdbox.Text = value.ToString(); }
        }
        internal int DestinationAdd
        {
            get { return DestAdBox.SelectedIndex; }
            set { DestAdBox.Text = value.ToString(); }
        }
        internal string fixedCost
        {
            get { return CostTxt.Text; }

            set { CostTxt.Text = value; }
        }

        
        private void LetterForm_Load(object sender, EventArgs e)
        {
            foreach (Address a in addressList)
            {
                OrginAdbox.Items.Add(a.Name);
                DestAdBox.Items.Add(a.Name);
            }
        }

        private void okbtn_Click(object sender, EventArgs e)// validates all data is correct and proceeds
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        private void Cancelbtn_Click(object sender, MouseEventArgs e)// validates left mouse button was clicked and cancels form if so.
        {
            if (e.Button == MouseButtons.Left)
                this.DialogResult = DialogResult.Cancel;
        }

        private void CostTxt_TextChanged(object sender, EventArgs e)
        {

        }
        //validation for all related fields in the Letter form.
        private void orginAD_validated(object sender, EventArgs e)//clears error providor once error is fixed.
        {
            errorProvider1.Clear();
        }

        private void orginAD_validating(object sender, CancelEventArgs e)
        {
            if (OrginAdbox.SelectedIndex < 0 ||  OrginAdbox == DestAdBox)
            {
                e.Cancel = true;
                errorProvider1.SetError(OrginAdbox, "enter a value for Origin address");
                OrginAdbox.SelectAll();
            }
        }

        private void desAD_validated(object sender, EventArgs e)
        {
            errorProvider1.Clear();
        }

        private void desAD_validating(object sender, CancelEventArgs e)
        {
            if (DestAdBox.SelectedIndex < 0 || DestAdBox.SelectedIndex == OrginAdbox.SelectedIndex)
            {
                e.Cancel = true;
                errorProvider1.SetError(DestAdBox, "enter a value for destination address");
                DestAdBox.SelectAll();
            }
        }
        private void FixedCost_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(CostTxt, "");
        }

        private void FixedCost_Validating(object sender, CancelEventArgs e)// vbalidates cost has been entered and ensuring theres not a non-negative value input.
        {
            int number;



            if(!int.TryParse(CostTxt.Text, out number))
            {
                e.Cancel = true;

                errorProvider1.SetError(CostTxt, "Enter an integer!");

                CostTxt.SelectAll();
            }
            else
            {
                if(number < 0)
                {
                    e.Cancel = true;

                    errorProvider1.SetError(CostTxt, "Enter a non-negative integer!");

                    CostTxt.SelectAll();
                }
                
            }
        }

       
    }
}
